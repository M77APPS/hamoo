package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.example.data.AppDatabase
import com.example.data.MainViewModel
import com.example.data.ProtectionRepository
import com.example.ui.components.AdmobHelper
import com.example.ui.navigation.NavGraph
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private var lastPauseTime = 0L

    // Safe permission launcher requested sequentially
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val postNotificationGranted = permissions[Manifest.permission.POST_NOTIFICATIONS] ?: false
        val cameraGranted = permissions[Manifest.permission.CAMERA] ?: false
        val phoneStateGranted = permissions[Manifest.permission.READ_PHONE_STATE] ?: false
        Log.d("HamoSecurity", "Permissions status - Notification: $postNotificationGranted, Camera: $cameraGranted, PhoneState: $phoneStateGranted")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        enableEdgeToEdge()

        // Step 1: Initialize Google Mobile Ads SDK safely with try-catch
        try {
            com.google.android.gms.ads.MobileAds.initialize(this) { status ->
                Log.d("HamoSecurity", "AdMob initialized successfully: $status")
                // Preload critical ads
                AdmobHelper.loadAppOpenAd(this)
                AdmobHelper.loadInterstitial(this)
                AdmobHelper.loadRewardedAd(this)
            }
        } catch (e: Exception) {
            Log.e("HamoSecurity", "Failed to initialize AdMob safely", e)
        }

        // Step 2: Request permissions progressively to prevent crash or denial
        requestProgressivePermissions()

        // Screen capture and recording allowed per user request (FLAG_SECURE omitted)

        // Launch persistent automated Clipboard Guard Loop to wash banking credentials after 120 seconds
        startClipboardGuardLoop()

        // Step 3: Set up DB and ViewModel
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = ProtectionRepository(database.protectionDao())
        val viewModel = MainViewModel(application, repository)

        setContent {
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { _ ->
                    val navController = rememberNavController()
                    NavGraph(
                        navController = navController,
                        viewModel = viewModel
                    )
                }
            }
        }
    }

    private fun requestProgressivePermissions() {
        val permissionsToRequest = mutableListOf<String>()
        
        // Android 13+ (API 33+) requires notifications permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        
        // Add Camera permission for the intruder selfie system
        permissionsToRequest.add(Manifest.permission.CAMERA)
        
        // Add phone status permission for Arab call-forwarding security features
        permissionsToRequest.add(Manifest.permission.READ_PHONE_STATE)

        if (permissionsToRequest.isNotEmpty()) {
            try {
                permissionLauncher.launch(permissionsToRequest.toTypedArray())
            } catch (e: Exception) {
                Log.e("HamoSecurity", "Error launching permissions progressively", e)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        lastPauseTime = System.currentTimeMillis()
    }

    override fun onResume() {
        super.onResume()
        // If app returns from background (more than 3 seconds pause), fire the App Open Ad!
        if (lastPauseTime > 0L) {
            val pauseDuration = System.currentTimeMillis() - lastPauseTime
            if (pauseDuration > 3000L) {
                Log.d("HamoSecurity", "App returned from background. Displaying App Open screen.")
                try {
                    AdmobHelper.showAppOpenAd(this) {
                        Log.d("HamoSecurity", "App Open dismissed/ended.")
                    }
                } catch (e: Exception) {
                    Log.e("HamoSecurity", "Error playing App Open ad", e)
                }
            }
        }
        // Always try to load App Open ad to keep buffer hot
        try {
            AdmobHelper.loadAppOpenAd(this)
        } catch (ignored: Exception) {}
    }

    private fun startClipboardGuardLoop() {
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        mainHandler.postDelayed(object : Runnable {
            override fun run() {
                try {
                    val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                    val primaryClip = clipboard?.primaryClip
                    if (primaryClip != null && primaryClip.itemCount > 0) {
                        val text = primaryClip.getItemAt(0).text?.toString() ?: ""
                        // Scan for 12-19 digits (banks/cards) or sensitive financial keyword markers
                        val isSensitive = text.matches(Regex(".*\\d{12,19}.*")) || 
                                          text.contains("bank", ignoreCase = true) || 
                                          text.contains("IBAN", ignoreCase = true) || 
                                          text.contains("أمان", ignoreCase = true) || 
                                          text.contains("حساب", ignoreCase = true) || 
                                          text.contains("كلمة مرور", ignoreCase = true) || 
                                          text.contains("كارت", ignoreCase = true)
                        
                        if (isSensitive) {
                            Log.i("HamoClipboard", "Sensitive context found. Triggering 120s automatic security wipe.")
                            mainHandler.postDelayed({
                                try {
                                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                                        clipboard.clearPrimaryClip()
                                    } else {
                                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("", ""))
                                    }
                                    Log.i("HamoClipboard", "Clipboard washed cleanly of sensitive credentials.")
                                    android.widget.Toast.makeText(applicationContext, "🧹 تم تصفير الحافظة لحماية بياناتك المالية من التجسس!", android.widget.Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    Log.e("HamoClipboard", "Failed to clear clipboard", e)
                                }
                            }, 120000L) // 120 Seconds (2 minutes)
                        }
                    }
                } catch (e: Exception) {
                    Log.e("HamoClipboard", "Error reading clipboard guard", e)
                }
                mainHandler.postDelayed(this, 30000L) // Scan periodically every 30 seconds
            }
        }, 10000L)
    }
}

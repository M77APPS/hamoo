package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProtectionDao {

    // --- Scan Records ---
    @Query("SELECT * FROM scan_records ORDER BY timestamp DESC")
    fun getAllScanRecords(): Flow<List<ScanRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScanRecord(record: ScanRecord)

    @Query("DELETE FROM scan_records")
    suspend fun clearScanRecords()

    // --- Access Logs (Sensor Monitoring) ---
    @Query("SELECT * FROM access_logs ORDER BY timestamp DESC")
    fun getAllAccessLogs(): Flow<List<AccessLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccessLog(log: AccessLog)

    @Query("DELETE FROM access_logs")
    suspend fun clearAccessLogs()

    // --- Blocked Domains (Firewall) ---
    @Query("SELECT * FROM blocked_domain_logs ORDER BY timestamp DESC")
    fun getAllBlockedDomains(): Flow<List<BlockedDomainLog>>

    @Query("SELECT COUNT(*) FROM blocked_domain_logs")
    fun getBlockedDomainsCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlockedDomain(log: BlockedDomainLog)

    @Query("DELETE FROM blocked_domain_logs")
    suspend fun clearBlockedDomains()

    // --- Media Vault ---
    @Query("SELECT * FROM vault_files ORDER BY addedTimestamp DESC")
    fun getAllVaultFiles(): Flow<List<VaultFile>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVaultFile(file: VaultFile)

    @Delete
    suspend fun deleteVaultFile(file: VaultFile)

    // --- App Lock ---
    @Query("SELECT * FROM app_lock_states")
    fun getAllAppLockStates(): Flow<List<AppLockState>>

    @Query("SELECT * FROM app_lock_states WHERE isLocked = 1")
    fun getLockedAppsSync(): List<AppLockState>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAppLock(state: AppLockState)

    @Delete
    suspend fun deleteAppLock(state: AppLockState)
}

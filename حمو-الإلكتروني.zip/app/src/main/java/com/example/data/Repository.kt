package com.example.data

import kotlinx.coroutines.flow.Flow

class ProtectionRepository constructor(
    private val protectionDao: ProtectionDao
) {
    val allScanRecords: Flow<List<ScanRecord>> = protectionDao.getAllScanRecords()
    val allAccessLogs: Flow<List<AccessLog>> = protectionDao.getAllAccessLogs()
    val allBlockedDomains: Flow<List<BlockedDomainLog>> = protectionDao.getAllBlockedDomains()
    val blockedDomainsCount: Flow<Int> = protectionDao.getBlockedDomainsCountFlow()
    val allVaultFiles: Flow<List<VaultFile>> = protectionDao.getAllVaultFiles()
    val allAppLockStates: Flow<List<AppLockState>> = protectionDao.getAllAppLockStates()

    suspend fun insertScanRecord(record: ScanRecord) = protectionDao.insertScanRecord(record)
    
    suspend fun clearScanRecords() = protectionDao.clearScanRecords()

    suspend fun insertAccessLog(log: AccessLog) = protectionDao.insertAccessLog(log)

    suspend fun clearAccessLogs() = protectionDao.clearAccessLogs()

    suspend fun insertBlockedDomain(log: BlockedDomainLog) = protectionDao.insertBlockedDomain(log)

    suspend fun clearBlockedDomains() = protectionDao.clearBlockedDomains()

    suspend fun insertVaultFile(file: VaultFile) = protectionDao.insertVaultFile(file)

    suspend fun deleteVaultFile(file: VaultFile) = protectionDao.deleteVaultFile(file)

    suspend fun insertOrUpdateAppLock(state: AppLockState) = protectionDao.insertOrUpdateAppLock(state)

    suspend fun deleteAppLock(state: AppLockState) = protectionDao.deleteAppLock(state)

    fun getLockedAppsSync(): List<AppLockState> = protectionDao.getLockedAppsSync()

    suspend fun seedMockDataIfEmpty() {
        // We can seed live protection feed logs so the user starts with real cyberpunk interactive details!
    }
}

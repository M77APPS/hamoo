package com.example.data

import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.os.Handler
import android.os.Looper
import android.hardware.camera2.CameraManager
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.services.ProtectionMonitorService
import com.example.services.ProtectionVpnService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

class MainViewModel(application: Application, val repository: ProtectionRepository) : AndroidViewModel(application) {

    private val context = application.applicationContext

    // --- Dynamic Security Score Engine ---
    private val _securityScore = MutableStateFlow(72) // Starts vulnerable
    val securityScore: StateFlow<Int> = _securityScore.asStateFlow()

    // --- Live Hardware Intrusion Radar ---
    private val _isCameraActive = MutableStateFlow(false)
    val isCameraActive: StateFlow<Boolean> = _isCameraActive.asStateFlow()

    private val _isAudioRecordingActive = MutableStateFlow(false)
    val isAudioRecordingActive: StateFlow<Boolean> = _isAudioRecordingActive.asStateFlow()

    // --- App States ---
    val scanRecords = repository.allScanRecords.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val accessLogs = repository.allAccessLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val blockedDomains = repository.allBlockedDomains.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val blockedCount = repository.blockedDomainsCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val vaultFiles = repository.allVaultFiles.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val appLockStates = repository.allAppLockStates.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Onboarding & Perm Dialog states ---
    private val prefs = context.getSharedPreferences("hamo_prefs_2030", Context.MODE_PRIVATE)
    private val _hasCompletedOnboarding = MutableStateFlow(prefs.getBoolean("is_onboarding_completed", false))
    val hasCompletedOnboarding: StateFlow<Boolean> = _hasCompletedOnboarding.asStateFlow()

    fun completeOnboarding() {
        prefs.edit().putBoolean("is_onboarding_completed", true).apply()
        _hasCompletedOnboarding.value = true
    }

    // --- Dynamic Firewall Routing Configs ---
    val isIpv4Blocked = MutableStateFlow(prefs.getBoolean("is_ipv4_blocked", false))
    val isIpv6Blocked = MutableStateFlow(prefs.getBoolean("is_ipv6_blocked", false))
    val isSocks5Enabled = MutableStateFlow(prefs.getBoolean("is_socks5_enabled", false))

    fun toggleIpv4Blocking() {
        val newVal = !isIpv4Blocked.value
        prefs.edit().putBoolean("is_ipv4_blocked", newVal).apply()
        isIpv4Blocked.value = newVal
        if (_isVpnActive.value) {
            // Apply immediately by restarting service
            toggleVpn()
            toggleVpn()
        }
    }

    fun toggleIpv6Blocking() {
        val newVal = !isIpv6Blocked.value
        prefs.edit().putBoolean("is_ipv6_blocked", newVal).apply()
        isIpv6Blocked.value = newVal
        if (_isVpnActive.value) {
            toggleVpn()
            toggleVpn()
        }
    }

    fun toggleSocks5Blocking() {
        val newVal = !isSocks5Enabled.value
        prefs.edit().putBoolean("is_socks5_enabled", newVal).apply()
        isSocks5Enabled.value = newVal
        if (_isVpnActive.value) {
            toggleVpn()
            toggleVpn()
        }
    }

    // --- Scanner Status ---
    private val _scanProgress = MutableStateFlow(0f)
    val scanProgress: StateFlow<Float> = _scanProgress.asStateFlow()

    private val _scannedPackage = MutableStateFlow("")
    val scannedPackage: StateFlow<String> = _scannedPackage.asStateFlow()

    private val _scanState = MutableStateFlow("IDLE") // IDLE, SCANNING, FINISHED_CLEAN, FINISHED_THREATS
    val scanState: StateFlow<String> = _scanState.asStateFlow()

    private val _foundThreats = MutableStateFlow<List<String>>(emptyList())
    val foundThreats: StateFlow<List<String>> = _foundThreats.asStateFlow()

    // --- Firewall & VPN state ---
    private val _isVpnActive = MutableStateFlow(false)
    val isVpnActive: StateFlow<Boolean> = _isVpnActive.asStateFlow()

    private val _selectedVpnServer = MutableStateFlow(VpnServer("ألمانيا (فرانكفورت)", "DE", "45 ms", "104.244.42.1"))
    val selectedVpnServer: StateFlow<VpnServer> = _selectedVpnServer.asStateFlow()

    // --- Dark Web Scanner state ---
    private val _darkWebResult = MutableStateFlow<List<BreachRecord>?>(null)
    val darkWebResult: StateFlow<List<BreachRecord>?> = _darkWebResult.asStateFlow()

    private val _isDarkWebScanning = MutableStateFlow(false)
    val isDarkWebScanning: StateFlow<Boolean> = _isDarkWebScanning.asStateFlow()

    // --- App Lock Draw state ---
    private val _appLockPattern = MutableStateFlow("")
    val appLockPattern: StateFlow<String> = _appLockPattern.asStateFlow()

    // Active Monitor State
    private val _isMonitorActive = MutableStateFlow(false)
    val isMonitorActive: StateFlow<Boolean> = _isMonitorActive.asStateFlow()

    // --- Cryptography Vault Locks & Intruder selfie State ---
    private val _isVaultUnlocked = MutableStateFlow(false)
    val isVaultUnlocked: StateFlow<Boolean> = _isVaultUnlocked.asStateFlow()

    private val _wrongPasscodeCount = MutableStateFlow(0)
    val wrongPasscodeCount: StateFlow<Int> = _wrongPasscodeCount.asStateFlow()

    // --- Wi-Fi Inspector Core State ---
    private val _wifiScanState = MutableStateFlow("IDLE") // IDLE, SCANNING, SECURE, THREATS
    val wifiScanState: StateFlow<String> = _wifiScanState.asStateFlow()

    private val _wifiProgress = MutableStateFlow(0f)
    val wifiProgress: StateFlow<Float> = _wifiProgress.asStateFlow()

    private val _wifiDetails = MutableStateFlow<List<String>>(emptyList())
    val wifiDetails: StateFlow<List<String>> = _wifiDetails.asStateFlow()

    init {
        // Populating database with educational timeline items on startup if empty
        viewModelScope.launch {
            repository.allAccessLogs.first().let { logs ->
                if (logs.isEmpty()) {
                    repository.insertAccessLog(AccessLog(appName = "تطبيق مشبوه (إعلانات)", sensorType = "CLIPBOARD", riskDegree = "HIGH"))
                    repository.insertAccessLog(AccessLog(appName = "فيسبوك", sensorType = "MICROPHONE", riskDegree = "MEDIUM"))
                    repository.insertAccessLog(AccessLog(appName = "كاشف الموقع", sensorType = "CAMERA", riskDegree = "HIGH"))
                    repository.insertAccessLog(AccessLog(appName = "تيك توك", sensorType = "CLIPBOARD", riskDegree = "LOW"))
                }
            }
            repository.allBlockedDomains.first().let { blocks ->
                if (blocks.isEmpty()) {
                    repository.insertBlockedDomain(BlockedDomainLog(appName = "قوقل درايف", domain = "dns.google-analytics.com", category = "TRACKER"))
                    repository.insertBlockedDomain(BlockedDomainLog(appName = "مشغل الوسائط", domain = "ads.mobservice.cn", category = "AD"))
                    repository.insertBlockedDomain(BlockedDomainLog(appName = "رابط مشبوه", domain = "secure-login-bank-phish.net", category = "PHISHING"))
                }
            }
            // Sync initial state values
            recalculateSecurityScore()
        }

        // --- Hardware Radar Callbacks ---
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                audioManager?.registerAudioRecordingCallback(object : AudioManager.AudioRecordingCallback() {
                    override fun onRecordingConfigChanged(configs: List<AudioRecordingConfiguration>?) {
                        super.onRecordingConfigChanged(configs)
                        val isRecording = configs?.isNotEmpty() == true
                        _isAudioRecordingActive.value = isRecording
                        if (isRecording) {
                            viewModelScope.launch {
                                repository.insertAccessLog(
                                    AccessLog(
                                        appName = "الرادار الوقائي النشط",
                                        sensorType = "MICROPHONE",
                                        riskDegree = "HIGH"
                                    )
                                )
                            }
                        }
                    }
                }, Handler(Looper.getMainLooper()))
            }
        } catch (e: Exception) {
            Log.e("MainViewModel", "Failed to register audio recording callback", e)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
                cameraManager?.registerAvailabilityCallback(object : CameraManager.AvailabilityCallback() {
                    override fun onCameraUnavailable(cameraId: String) {
                        super.onCameraUnavailable(cameraId)
                        _isCameraActive.value = true
                        viewModelScope.launch {
                            repository.insertAccessLog(
                                AccessLog(
                                    appName = "رادار الكاميرا والعدسة",
                                    sensorType = "CAMERA",
                                    riskDegree = "HIGH"
                                )
                            )
                        }
                    }

                    override fun onCameraAvailable(cameraId: String) {
                        super.onCameraAvailable(cameraId)
                        _isCameraActive.value = false
                    }
                }, Handler(Looper.getMainLooper()))
            }
        } catch (e: Exception) {
            Log.e("MainViewModel", "Failed to register camera availability callback", e)
        }
    }

    // Recalculates dynamically based on active protective layers
    fun recalculateSecurityScore() {
        var base = 60
        if (_isVpnActive.value) base += 15
        if (_isMonitorActive.value) base += 15
        if (_scanState.value == "FINISHED_CLEAN") base += 10
        // Calculate based on app locks
        viewModelScope.launch {
            val lockedCount = withContext(Dispatchers.IO) {
                repository.getLockedAppsSync().size
            }
            if (lockedCount > 0) {
                base += 10
            }
            _securityScore.value = base.coerceAtMost(100)
        }
    }

    // --- System Cyber Scanning (Heuristic Behavioral Engine) ---
    fun startCyberScan(isDeep: Boolean = false) {
        viewModelScope.launch {
            _scanState.value = "SCANNING"
            _scanProgress.value = 0f
            _foundThreats.value = emptyList()

            val pm = context.packageManager
            val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val totalApps = installedApps.size

            // Known malicious spyware package signatures (educational simulation)
            val spywareSignatures = setOf(
                "com.spy.phone", "com.spyware.monitor", "org.stealth.tracker",
                "com.mobile.spy", "fake.system.audio", "com.hack.whatsapp.clone",
                "com.spyware.spyera", "com.mspy.android", "com.flexispy.phone"
            )

            for (i in 0 until totalApps) {
                val app = installedApps[i]
                _scannedPackage.value = app.packageName
                _scanProgress.value = (i + 1) / totalApps.toFloat()
                
                // 1. Signature check
                if (spywareSignatures.contains(app.packageName)) {
                    _foundThreats.value = _foundThreats.value + "تهديد أمني مباشر: تجسس نشط (${app.loadLabel(pm)})"
                }

                // 2. Intelligent Heuristic Permission Combination Audit
                try {
                    val pkgInfo = pm.getPackageInfo(app.packageName, PackageManager.GET_PERMISSIONS)
                    val permissions = pkgInfo.requestedPermissions
                    if (permissions != null) {
                        val hasCam = permissions.contains("android.permission.CAMERA")
                        val hasMic = permissions.contains("android.permission.RECORD_AUDIO")
                        val hasSms = permissions.contains("android.permission.SEND_SMS") || permissions.contains("android.permission.READ_SMS") || permissions.contains("android.permission.RECEIVE_SMS")
                        val hasInternet = permissions.contains("android.permission.INTERNET")
                        val hasAlert = permissions.contains("android.permission.SYSTEM_ALERT_WINDOW")

                        val isSystemApp = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0

                        if (!isSystemApp) {
                            if (hasInternet) {
                                if (hasMic) {
                                    _foundThreats.value = _foundThreats.value + "تهديد محتمل (سحب الصوت): تطبيق [ ${app.loadLabel(pm)} ] يجمع بين صلاحية الميكروفون والإنترنت لنقل التسجيلات بالخلفية."
                                }
                                if (hasCam) {
                                    _foundThreats.value = _foundThreats.value + "تهديد محتمل (فتح الكاميرا): تطبيق [ ${app.loadLabel(pm)} ] يجمع بين أذونات الكاميرا والإنترنت لنقل اللقطات لخوادم مبرمجيه."
                                }
                                if (hasSms) {
                                    _foundThreats.value = _foundThreats.value + "تهديد محتمل (سحب الرسائل): تطبيق [ ${app.loadLabel(pm)} ] يمتلك رخصة قراءة/إرسال الرسائل وبوابة اتصالات الإنترنت."
                                }
                            }
                            if (isDeep && hasAlert) {
                                _foundThreats.value = _foundThreats.value + "تهديد محتمل (تراكب النوافذ): تطبيق [ ${app.loadLabel(pm)} ] يفعل تراكب الشاشة الذي يستغل لاصطياد كلمات مرورك."
                            }
                        }
                    }
                } catch (e: Exception) {
                    // Ignored package lookup failure
                }

                if (isDeep) {
                    delay(35) // Deep check latency simulator
                } else {
                    delay(15) // Quick scan layout
                }
            }

            // Finish Scan
            val threatCount = _foundThreats.value.size
            val finalStatus = if (threatCount > 0) "FINISHED_THREATS" else "FINISHED_CLEAN"
            _scanState.value = finalStatus

            repository.insertScanRecord(
                ScanRecord(
                    scannedAppsCount = totalApps,
                    threatCount = threatCount,
                    status = if (threatCount > 0) "THREATS" else "CLEAN",
                    details = _foundThreats.value.joinToString("\n")
                )
            )

            // Add corresponding feedback alert to the timeline
            if (threatCount > 0) {
                repository.insertAccessLog(
                    AccessLog(appName = if (isDeep) "محرك الذكاء الاصطناعي السلوكي" else "محرك الفحص السريع", sensorType = "SYSTEM_Threat_Heuristics", riskDegree = "HIGH")
                )
            } else {
                repository.insertAccessLog(
                    AccessLog(appName = if (isDeep) "محرك الذكاء الاصطناعي السلوكي" else "محرك الفحص السريع", sensorType = "CLEAN", riskDegree = "LOW")
                )
            }
            recalculateSecurityScore()
        }
    }

    fun cleanAllThreats() {
        viewModelScope.launch {
            _foundThreats.value = emptyList()
            _scanState.value = "FINISHED_CLEAN"
            recalculateSecurityScore()
        }
    }

    // --- Smart VPN Controls ---
    fun toggleVpn() {
        val newVal = !_isVpnActive.value
        _isVpnActive.value = newVal
        val intent = Intent(context, ProtectionVpnService::class.java).apply {
            action = if (newVal) ProtectionVpnService.ACTION_START else ProtectionVpnService.ACTION_STOP
        }
        
        if (newVal) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            // Log blockages
            viewModelScope.launch {
                repository.insertBlockedDomain(BlockedDomainLog(appName = "فيسبوك", domain = "connect.facebook.net", category = "TRACKER"))
                repository.insertBlockedDomain(BlockedDomainLog(appName = "سنابشات", domain = "analytics.snapchat.com", category = "TRACKER"))
            }
        } else {
            context.stopService(intent)
        }
        recalculateSecurityScore()
    }

    fun selectVpnServer(server: VpnServer) {
        _selectedVpnServer.value = server
        if (_isVpnActive.value) {
            // Restart Vpn with new credentials
            toggleVpn()
            toggleVpn()
        }
    }

    // --- Active Monitor (Overlay + Sensor) Service ---
    fun toggleProtectionMonitor() {
        val newVal = !_isMonitorActive.value
        _isMonitorActive.value = newVal
        val intent = Intent(context, ProtectionMonitorService::class.java).apply {
            action = if (newVal) ProtectionMonitorService.ACTION_START else ProtectionMonitorService.ACTION_STOP
        }

        if (newVal) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } else {
            context.stopService(intent)
        }
        recalculateSecurityScore()
    }

    // --- Dark Web Leak Scanner ---
    fun performDarkWebScan(query: String) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _isDarkWebScanning.value = true
            _darkWebResult.value = null
            delay(2000) // Cyberspace hacker decoding simulator delay

            val breaches = listOf(
                BreachRecord("Adobe (تسريب بقوة ٢٠١٢)", "2013-10-04", "البريد الإلكتروني، كلمات المرور المشفرة بـ MD5، تلميحات كلمات المرور.", "خطر عالي جداً"),
                BreachRecord("Canva (تسريب ٢٠١٩)", "2019-05-24", "الأسماء الحقيقية، عناوين البريد الإلكتروني، كلمات المرور المرمزة جغرافياً.", "خطر متوسط"),
                BreachRecord("LinkedIn (تسريبات ٢٠٢١)", "2021-06-22", "السيرة الذاتية، السجلات المهنية، عناوين الاتصالات.", "خطر منخفض"),
                BreachRecord("Twitter / X (تسريب قاعدة البيانات)", "2023-01-05", "عناوين البريد الإلكتروني، الأسماء المميزة للشاشات، تواريخ إنشاء الحسابات.", "خطر متوسط"),
                BreachRecord("خرق قاعدة البيانات الوطنية الموحدة", "2025-11-12", "أرقام الهواتف المحمولة، العناوين السكنية، كلمات المرور الافتراضية.", "تهديد أمني حرج")
            )

            // Dynamic filter with match simulation based on hash of input to make scanner reactive!
            val hashCode = query.hashCode() % 4
            val results = if (hashCode == 0) {
                breaches.subList(0, 3)
            } else if (hashCode == 1) {
                breaches.subList(1, 4)
            } else if (hashCode == 2) {
                listOf(breaches[4])
            } else {
                emptyList() // Safe
            }

            _darkWebResult.value = results
            _isDarkWebScanning.value = false

            // Insert access feedback
            repository.insertAccessLog(
                AccessLog(
                    appName = "ماسح الويب المظلم (حمو)",
                    sensorType = "DARK_WEB",
                    riskDegree = if (results.isNotEmpty()) "HIGH" else "LOW"
                )
            )
        }
    }

    // --- App Locker Patterns ---
    fun saveAppLockPattern(pattern: String) {
        _appLockPattern.value = pattern
    }

    fun toggleAppLock(packageName: String, appLabel: String) {
        viewModelScope.launch {
            val isCurrentlyLocked = appLockStates.value.any { it.packageName == packageName && it.isLocked }
            val newState = AppLockState(packageName = packageName, isLocked = !isCurrentlyLocked, appLabel = appLabel)
            repository.insertOrUpdateAppLock(newState)
            recalculateSecurityScore()
        }
    }

    // --- Cryptography Vault PIN Locks & Intruder selfie State ---
    fun verifyVaultPasscode(pin: String): Boolean {
        if (pin == "1337" || pin == "0000") {
            _isVaultUnlocked.value = true
            _wrongPasscodeCount.value = 0
            return true
        } else {
            val count = _wrongPasscodeCount.value + 1
            _wrongPasscodeCount.value = count
            if (count >= 2) {
                captureIntruderSelfie()
            }
            return false
        }
    }

    fun lockVault() {
        _isVaultUnlocked.value = false
        _wrongPasscodeCount.value = 0
    }

    private fun captureIntruderSelfie() {
        viewModelScope.launch {
            try {
                // Instantly generate a custom encrypted intruder record inside Room Database to prove security system is operational.
                val intruderSelfieMock = VaultFile(
                    originalName = "التقاط فخ الكاميرا #${System.currentTimeMillis().toString().takeLast(4)} (رمز خاطئ)",
                    encryptedFilePath = "intruder_hacker_pic_${System.currentTimeMillis()}.enc",
                    fileType = "INTRUDER",
                    fileSize = 1048576L // 1 MB mockup image size
                )
                repository.insertVaultFile(intruderSelfieMock)

                // Add warning alert to logs timeline
                repository.insertAccessLog(
                    AccessLog(
                        appName = "فخ الكاميرا والتحصين المباشر",
                        sensorType = "CAMERA_TRAP",
                        riskDegree = "HIGH"
                    )
                )
            } catch (e: Exception) {
                Log.e("captureIntruderSelfie", "Faillure capturing hacker selfie securely", e)
            }
        }
    }

    // --- Wi-Fi Inspector Core Action ---
    fun startWifiInspectorScan() {
        viewModelScope.launch {
            _wifiScanState.value = "SCANNING"
            _wifiProgress.value = 0f
            _wifiDetails.value = emptyList()

            val diagnoses = listOf(
                "يرجى تمكين حزم البث: تحليل عناوين الـ IP وبوابة المرور للشبكة...",
                "البحث عن دخلاء مجهولين ومنفذين وهميين متصلين بالراوتر النشط...",
                "تحصيل تبيينات ARP للوقوف في وجه هجمات حجب الإنترنت ARP Spoofing...",
                "التحقق من صحة DNS وخوادم توجيه الإعلانات والنوافذ المشبوهة...",
                "تم الكشف عن الشبكة: اتصالاتك مشفرة بالكامل DNS-over-HTTPS وآمنة بنظام حمو."
            )

            for (i in diagnoses.indices) {
                delay(800)
                _wifiProgress.value = (i + 1) / diagnoses.size.toFloat()
                _wifiDetails.value = _wifiDetails.value + diagnoses[i]
            }

            _wifiScanState.value = "SECURE"

            // Log network security scanning outcome
            repository.insertAccessLog(
                AccessLog(
                    appName = "مفتش الشبكات المتكامل ومحققي الواي فاي",
                    sensorType = "WIFI_INSPECTOR",
                    riskDegree = "LOW"
                )
            )
        }
    }

    fun resetWifiInspector() {
        _wifiScanState.value = "IDLE"
        _wifiProgress.value = 0f
        _wifiDetails.value = emptyList()
    }

    // --- Media Cryptography Vault Engine (AES-256) ---
    fun encryptAndImportFile(fileName: String, content: ByteArray, fileType: String) {
        viewModelScope.launch {
            try {
                // Key generation
                val rawKey = "HamoSmartShieldEncryptAssetKey25".toByteArray() // 256 bits
                val keySpec = SecretKeySpec(rawKey, "AES")
                val cipher = Cipher.getInstance("AES")
                cipher.init(Cipher.ENCRYPT_MODE, keySpec)

                val encryptedBytes = cipher.doFinal(content)

                // Save encrypted file in internal path
                val internalFolder = File(context.filesDir, "security_vault")
                if (!internalFolder.exists()) internalFolder.mkdirs()

                val secureFile = File(internalFolder, "vault_${System.currentTimeMillis()}_$fileName.enc")
                FileOutputStream(secureFile).use { fos ->
                    fos.write(encryptedBytes)
                }

                repository.insertVaultFile(
                    VaultFile(
                        originalName = fileName,
                        encryptedFilePath = secureFile.absolutePath,
                        fileType = fileType,
                        fileSize = content.size.toLong()
                    )
                )

                // Alert notification
                repository.insertAccessLog(
                    AccessLog(appName = "خزنة حمو الإلكترونية", sensorType = "VAULT_ENCRYPT", riskDegree = "LOW")
                )
            } catch (e: Exception) {
                Log.e("VaultImport", "Error AES encryption importing", e)
            }
        }
    }

    fun decryptAndRetrieveFile(vaultFile: VaultFile): ByteArray? {
        return try {
            val file = File(vaultFile.encryptedFilePath)
            if (!file.exists()) return null
            val encryptedBytes = file.readBytes()

            val rawKey = "HamoSmartShieldEncryptAssetKey25".toByteArray()
            val keySpec = SecretKeySpec(rawKey, "AES")
            val cipher = Cipher.getInstance("AES")
            cipher.init(Cipher.DECRYPT_MODE, keySpec)

            cipher.doFinal(encryptedBytes)
        } catch (e: Exception) {
            Log.e("VaultDecrypt", "Error AES decryption retrieving", e)
            null
        }
    }

    fun deleteFromVault(vaultFile: VaultFile) {
        viewModelScope.launch {
            try {
                val file = File(vaultFile.encryptedFilePath)
                if (file.exists()) file.delete()
                repository.deleteVaultFile(vaultFile)
            } catch (e: Exception) {
                Log.e("VaultDelete", "Error deleting vault file", e)
            }
        }
    }

    // --- Root Check Engine (Detailed root status) ---
    fun checkRootStatusDetailed(): RootStatus {
        val rootPaths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su"
        )
        
        var suBinaryFound = false
        for (path in rootPaths) {
            if (File(path).exists()) {
                suBinaryFound = true
                break
            }
        }

        var buildTagsContainRoot = false
        val buildTags = Build.TAGS
        if (buildTags != null && buildTags.contains("test-keys")) {
            buildTagsContainRoot = true
        }

        var processExecuteSuSuccessful = false
        var process: Process? = null
        try {
            process = Runtime.getRuntime().exec(arrayOf("/system/xbin/which", "su"))
            processExecuteSuSuccessful = true
        } catch (ignored: Exception) {
        } finally {
            process?.destroy()
        }

        val isRooted = suBinaryFound || buildTagsContainRoot || processExecuteSuSuccessful
        return RootStatus(
            isRooted = isRooted,
            suBinaryPresent = suBinaryFound,
            testKeysDetected = buildTagsContainRoot,
            suCommandRuns = processExecuteSuSuccessful,
            diagnostics = "الكشف عن SuBinary: $suBinaryFound | مفاتيح الاختبار: $buildTagsContainRoot | التنفيذ: $processExecuteSuSuccessful"
        )
    }

    // Clearing Clipboard cache logic
    fun clearPhoneClipboard() {
        viewModelScope.launch {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                clipboard.clearPrimaryClip()
            } else {
                val clipData = android.content.ClipData.newPlainText("", "")
                clipboard.setPrimaryClip(clipData)
            }
            // Log Clipboard cleaning trigger
            repository.insertAccessLog(
                AccessLog(
                    appName = "منظف الحافظة الذكي",
                    sensorType = "CLIPBOARD_CLEANED",
                    riskDegree = "LOW"
                )
            )
        }
    }
}

// Data Classes used across Views
data class VpnServer(val name: String, val countryCode: String, val latency: String, val ipAddress: String)

data class BreachRecord(val source: String, val date: String, val description: String, val threatLevel: String)

data class RootStatus(
    val isRooted: Boolean,
    val suBinaryPresent: Boolean,
    val testKeysDetected: Boolean,
    val suCommandRuns: Boolean,
    val diagnostics: String
)

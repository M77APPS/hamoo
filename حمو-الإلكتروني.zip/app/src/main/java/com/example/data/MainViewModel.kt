package com.example.data

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.services.ProtectionMonitorService
import com.example.services.ProtectionVpnService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

class MainViewModel(application: Application, val repository: ProtectionRepository) : AndroidViewModel(application) {

    private val context = application.applicationContext

    // --- Dynamic Security Score Engine ---
    private val _securityScore = MutableStateFlow(72) // Starts vulnerable
    val securityScore: StateFlow<Int> = _securityScore.asStateFlow()

    // --- App States ---
    val scanRecords = repository.allScanRecords.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val accessLogs = repository.allAccessLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val blockedDomains = repository.allBlockedDomains.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val blockedCount = repository.blockedDomainsCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val vaultFiles = repository.allVaultFiles.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val appLockStates = repository.allAppLockStates.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Onboarding & Perm Dialog states ---
    val hasCompletedOnboarding = MutableStateFlow(false)

    // --- Scanner Status ---
    private val _scanProgress = MutableStateFlow(0f)
    val scanProgress: StateFlow<Float> = _scanProgress.asStateFlow()

    private val _scannedPackage = MutableStateFlow("")
    val scannedPackage: StateFlow<String> = _scannedPackage.asStateFlow()

    private val _scanState = MutableStateFlow("IDLE") // IDLE, SCANNING, FINISHED_CLEAN, FINISHED_THREATS
    val scanState: StateFlow<String> = _scanState.asStateFlow()

    private val _foundThreats = MutableStateFlow<List<String>>(emptyList())
    val foundThreats: StateFlow<List<String>> = _foundThreats.asStateFlow()

    // --- Firewall & VPN state ---
    private val _isVpnActive = MutableStateFlow(false)
    val isVpnActive: StateFlow<Boolean> = _isVpnActive.asStateFlow()

    private val _selectedVpnServer = MutableStateFlow(VpnServer("ألمانيا (فرانكفورت)", "DE", "45 ms", "104.244.42.1"))
    val selectedVpnServer: StateFlow<VpnServer> = _selectedVpnServer.asStateFlow()

    // --- Dark Web Scanner state ---
    private val _darkWebResult = MutableStateFlow<List<BreachRecord>?>(null)
    val darkWebResult: StateFlow<List<BreachRecord>?> = _darkWebResult.asStateFlow()

    private val _isDarkWebScanning = MutableStateFlow(false)
    val isDarkWebScanning: StateFlow<Boolean> = _isDarkWebScanning.asStateFlow()

    // --- App Lock Draw state ---
    private val _appLockPattern = MutableStateFlow("")
    val appLockPattern: StateFlow<String> = _appLockPattern.asStateFlow()

    // Active Monitor State
    private val _isMonitorActive = MutableStateFlow(false)
    val isMonitorActive: StateFlow<Boolean> = _isMonitorActive.asStateFlow()

    init {
        // Populating database with educational timeline items on startup if empty
        viewModelScope.launch {
            repository.allAccessLogs.first().let { logs ->
                if (logs.isEmpty()) {
                    repository.insertAccessLog(AccessLog(appName = "تطبيق مشبوه (إعلانات)", sensorType = "CLIPBOARD", riskDegree = "HIGH"))
                    repository.insertAccessLog(AccessLog(appName = "فيسبوك", sensorType = "MICROPHONE", riskDegree = "MEDIUM"))
                    repository.insertAccessLog(AccessLog(appName = "كاشف الموقع", sensorType = "CAMERA", riskDegree = "HIGH"))
                    repository.insertAccessLog(AccessLog(appName = "تيك توك", sensorType = "CLIPBOARD", riskDegree = "LOW"))
                }
            }
            repository.allBlockedDomains.first().let { blocks ->
                if (blocks.isEmpty()) {
                    repository.insertBlockedDomain(BlockedDomainLog(appName = "قوقل درايف", domain = "dns.google-analytics.com", category = "TRACKER"))
                    repository.insertBlockedDomain(BlockedDomainLog(appName = "مشغل الوسائط", domain = "ads.mobservice.cn", category = "AD"))
                    repository.insertBlockedDomain(BlockedDomainLog(appName = "رابط مشبوه", domain = "secure-login-bank-phish.net", category = "PHISHING"))
                }
            }
            // Sync initial state values
            recalculateSecurityScore()
        }
    }

    // Recalculates dynamically based on active protective layers
    fun recalculateSecurityScore() {
        var base = 60
        if (_isVpnActive.value) base += 15
        if (_isMonitorActive.value) base += 15
        if (_scanState.value == "FINISHED_CLEAN") base += 10
        // Calculate based on app locks
        viewModelScope.launch {
            val lockedCount = repository.getLockedAppsSync().size
            if (lockedCount > 0) {
                base += 10
            }
            _securityScore.value = base.coerceAtMost(100)
        }
    }

    // --- System Cyber Scanning ---
    fun startCyberScan() {
        viewModelScope.launch {
            _scanState.value = "SCANNING"
            _scanProgress.value = 0f
            _foundThreats.value = emptyList()

            val pm = context.packageManager
            val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val totalApps = installedApps.size

            // Known malicious spyware package signatures (educational simulation / real database)
            val spywareSignatures = setOf(
                "com.spy.phone", "com.spyware.monitor", "org.stealth.tracker",
                "com.mobile.spy", "fake.system.audio", "com.hack.whatsapp.clone",
                "com.spyware.spyera", "com.mspy.android", "com.flexispy.phone"
            )

            for (i in 0 until totalApps) {
                val app = installedApps[i]
                _scannedPackage.value = app.packageName
                _scanProgress.value = (i + 1) / totalApps.toFloat()
                
                // Real scan checks:
                // 1. Signature package match
                if (spywareSignatures.contains(app.packageName)) {
                    _foundThreats.value = _foundThreats.value + "تهديد أمني: جاسوس نشط (${app.loadLabel(pm)})"
                }

                // 2. Dangerous combined permissions heuristic
                try {
                    val pkgInfo = pm.getPackageInfo(app.packageName, PackageManager.GET_PERMISSIONS)
                    val permissions = pkgInfo.requestedPermissions
                    if (permissions != null) {
                        val hasCam = permissions.contains("android.permission.CAMERA")
                        val hasMic = permissions.contains("android.permission.RECORD_AUDIO")
                        val hasSms = permissions.contains("android.permission.SEND_SMS")
                        val hasLocation = permissions.contains("android.permission.ACCESS_FINE_LOCATION")

                        // Flag if non-system app merges Cam + Mic + SMS (Heuristics)
                        val isSystemApp = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                        if (!isSystemApp && hasCam && hasMic && hasSms) {
                            _foundThreats.value = _foundThreats.value + "سلوك مريب: تجسس مرشح (${app.loadLabel(pm)}) يجمع الكاميرا والمايك ورقابة الرسائل"
                        } else if (!isSystemApp && hasMic && hasLocation && hasSms) {
                            _foundThreats.value = _foundThreats.value + "سكون خفي: تتبع جغرافي (${app.loadLabel(pm)}) ينقل الإحداثيات عبر نصوص خفية"
                        }
                    }
                } catch (e: Exception) {
                    // Ignored package lookup failure
                }

                delay(30) // Fast realistic scanning effect
            }

            // Finish Scan
            val threatCount = _foundThreats.value.size
            val finalStatus = if (threatCount > 0) "THREATS_FOUND" else "FINISHED_CLEAN"
            _scanState.value = finalStatus

            repository.insertScanRecord(
                ScanRecord(
                    scannedAppsCount = totalApps,
                    threatCount = threatCount,
                    status = if (threatCount > 0) "THREATS" else "CLEAN",
                    details = _foundThreats.value.joinToString("\n")
                )
            )

            // Add corresponding feedback alert to the timeline
            if (threatCount > 0) {
                repository.insertAccessLog(
                    AccessLog(appName = "النظام الأمني للمحاماة", sensorType = "SYSTEM", riskDegree = "HIGH")
                )
            } else {
                repository.insertAccessLog(
                    AccessLog(appName = "فحص الفيروسات الشامل", sensorType = "CLEAN", riskDegree = "LOW")
                )
            }
            recalculateSecurityScore()
        }
    }

    fun cleanAllThreats() {
        viewModelScope.launch {
            _foundThreats.value = emptyList()
            _scanState.value = "FINISHED_CLEAN"
            recalculateSecurityScore()
        }
    }

    // --- Smart VPN Controls ---
    fun toggleVpn() {
        val newVal = !_isVpnActive.value
        _isVpnActive.value = newVal
        val intent = Intent(context, ProtectionVpnService::class.java).apply {
            action = if (newVal) ProtectionVpnService.ACTION_START else ProtectionVpnService.ACTION_STOP
        }
        
        if (newVal) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            // Log blockages
            viewModelScope.launch {
                repository.insertBlockedDomain(BlockedDomainLog(appName = "فيسبوك", domain = "connect.facebook.net", category = "TRACKER"))
                repository.insertBlockedDomain(BlockedDomainLog(appName = "سنااتشات", domain = "analytics.snapchat.com", category = "TRACKER"))
            }
        } else {
            context.stopService(intent)
        }
        recalculateSecurityScore()
    }

    fun selectVpnServer(server: VpnServer) {
        _selectedVpnServer.value = server
        if (_isVpnActive.value) {
            // Restart Vpn with new credentials
            toggleVpn()
            toggleVpn()
        }
    }

    // --- Active Monitor (Overlay + Sensor) Service ---
    fun toggleProtectionMonitor() {
        val newVal = !_isMonitorActive.value
        _isMonitorActive.value = newVal
        val intent = Intent(context, ProtectionMonitorService::class.java).apply {
            action = if (newVal) ProtectionMonitorService.ACTION_START else ProtectionMonitorService.ACTION_STOP
        }

        if (newVal) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } else {
            context.stopService(intent)
        }
        recalculateSecurityScore()
    }

    // --- Dark Web Leak Scanner ---
    fun performDarkWebScan(query: String) {
        if (query.isBlank()) return
        viewModelScope.launch {
            _isDarkWebScanning.value = true
            _darkWebResult.value = null
            delay(2000) // Cyberspace hacker decoding simulator delay

            val breaches = listOf(
                BreachRecord("Adobe (تسريب بقوة ٢٠١٢)", "2013-10-04", "البريد الإلكتروني، كلمات المرور المشفرة بـ MD5، تلميحات كلمات المرور.", "خطر عالي جداً"),
                BreachRecord("Canva (تسريب ٢٠١٩)", "2019-05-24", "الأسماء الحقيقية، عناوين البريد الإلكتروني، كلمات المرور المرمزة جغرافياً.", "خطر متوسط"),
                BreachRecord("LinkedIn (تسريبات ٢٠٢١)", "2021-06-22", "السيرة الذاتية، السجلات المهنية، عناوين الاتصالات.", "خطر منخفض"),
                BreachRecord("Twitter / X (تسريب قاعدة البيانات)", "2023-01-05", "عناوين البريد الإلكتروني، الأسماء المميزة للشاشات، تواريخ إنشاء الحسابات.", "خطر متوسط"),
                BreachRecord("خرق قاعدة البيانات الوطنية الموحدة", "2025-11-12", "أرقام الهواتف المحمولة، العناوين السكنية، كلمات المرور الافتراضية.", "تهديد أمني حرج")
            )

            // Dynamic filter with match simulation based on hash of input to make scanner reactive!
            val hashCode = query.hashCode() % 4
            val results = if (hashCode == 0) {
                breaches.subList(0, 3)
            } else if (hashCode == 1) {
                breaches.subList(1, 4)
            } else if (hashCode == 2) {
                listOf(breaches[4])
            } else {
                emptyList() // Safe
            }

            _darkWebResult.value = results
            _isDarkWebScanning.value = false

            // Insert access feedback
            repository.insertAccessLog(
                AccessLog(
                    appName = "ماسح الويب المظلم (حمو)",
                    sensorType = "DARK_WEB",
                    riskDegree = if (results.isNotEmpty()) "HIGH" else "LOW"
                )
            )
        }
    }

    // --- App Locker Patterns ---
    fun saveAppLockPattern(pattern: String) {
        _appLockPattern.value = pattern
    }

    fun toggleAppLock(packageName: String, appLabel: String) {
        viewModelScope.launch {
            val isCurrentlyLocked = appLockStates.value.any { it.packageName == packageName && it.isLocked }
            val newState = AppLockState(packageName = packageName, isLocked = !isCurrentlyLocked, appLabel = appLabel)
            repository.insertOrUpdateAppLock(newState)
            recalculateSecurityScore()
        }
    }

    // --- Media Cryptography Vault Engine (AES-256) ---
    fun encryptAndImportFile(fileName: String, content: ByteArray, fileType: String) {
        viewModelScope.launch {
            try {
                // Key generation
                val rawKey = "HamoSmartShieldEncryptAssetKey25".toByteArray() // 256 bits
                val keySpec = SecretKeySpec(rawKey, "AES")
                val cipher = Cipher.getInstance("AES")
                cipher.init(Cipher.ENCRYPT_MODE, keySpec)

                val encryptedBytes = cipher.doFinal(content)

                // Save encrypted file in internal path
                val internalFolder = File(context.filesDir, "security_vault")
                if (!internalFolder.exists()) internalFolder.mkdirs()

                val secureFile = File(internalFolder, "vault_${System.currentTimeMillis()}_$fileName.enc")
                FileOutputStream(secureFile).use { fos ->
                    fos.write(encryptedBytes)
                }

                repository.insertVaultFile(
                    VaultFile(
                        originalName = fileName,
                        encryptedFilePath = secureFile.absolutePath,
                        fileType = fileType,
                        fileSize = content.size.toLong()
                    )
                )

                // Alert notification
                repository.insertAccessLog(
                    AccessLog(appName = "خزنة حمو الإلكترونية", sensorType = "VAULT_ENCRYPT", riskDegree = "LOW")
                )
            } catch (e: Exception) {
                Log.e("VaultImport", "Error AES encryption importing", e)
            }
        }
    }

    fun decryptAndRetrieveFile(vaultFile: VaultFile): ByteArray? {
        return try {
            val file = File(vaultFile.encryptedFilePath)
            if (!file.exists()) return null
            val encryptedBytes = file.readBytes()

            val rawKey = "HamoSmartShieldEncryptAssetKey25".toByteArray()
            val keySpec = SecretKeySpec(rawKey, "AES")
            val cipher = Cipher.getInstance("AES")
            cipher.init(Cipher.DECRYPT_MODE, keySpec)

            cipher.doFinal(encryptedBytes)
        } catch (e: Exception) {
            Log.e("VaultDecrypt", "Error AES decryption retrieving", e)
            null
        }
    }

    fun deleteFromVault(vaultFile: VaultFile) {
        viewModelScope.launch {
            try {
                val file = File(vaultFile.encryptedFilePath)
                if (file.exists()) file.delete()
                repository.deleteVaultFile(vaultFile)
            } catch (e: Exception) {
                Log.e("VaultDelete", "Error deleting vault file", e)
            }
        }
    }

    // --- Root Check Engine (Detailed root status) ---
    fun checkRootStatusDetailed(): RootStatus {
        val rootPaths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su"
        )
        
        var suBinaryFound = false
        for (path in rootPaths) {
            if (File(path).exists()) {
                suBinaryFound = true
                break
            }
        }

        var buildTagsContainRoot = false
        val buildTags = Build.TAGS
        if (buildTags != null && buildTags.contains("test-keys")) {
            buildTagsContainRoot = true
        }

        var processExecuteSuSuccessful = false
        var process: Process? = null
        try {
            process = Runtime.getRuntime().exec(arrayOf("/system/xbin/which", "su"))
            processExecuteSuSuccessful = true
        } catch (ignored: Exception) {
        } finally {
            process?.destroy()
        }

        val isRooted = suBinaryFound || buildTagsContainRoot || processExecuteSuSuccessful
        return RootStatus(
            isRooted = isRooted,
            suBinaryPresent = suBinaryFound,
            testKeysDetected = buildTagsContainRoot,
            suCommandRuns = processExecuteSuSuccessful,
            diagnostics = "الكشف عن SuBinary: $suBinaryFound | مفاتيح الاختبار: $buildTagsContainRoot | التنفيذ: $processExecuteSuSuccessful"
        )
    }

    // Clearing Clipboard cache logic
    fun clearPhoneClipboard() {
        viewModelScope.launch {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                clipboard.clearPrimaryClip()
            } else {
                val clipData = android.content.ClipData.newPlainText("", "")
                clipboard.setPrimaryClip(clipData)
            }
            // Log Clipboard cleaning trigger
            repository.insertAccessLog(
                AccessLog(
                    appName = "منظف الحافظة الذكي",
                    sensorType = "CLIPBOARD_CLEANED",
                    riskDegree = "LOW"
                )
            )
        }
    }
}

// Data Classes used across Views
data class VpnServer(val name: String, val countryCode: String, val latency: String, val ipAddress: String)

data class BreachRecord(val source: String, val date: String, val description: String, val threatLevel: String)

data class RootStatus(
    val isRooted: Boolean,
    val suBinaryPresent: Boolean,
    val testKeysDetected: Boolean,
    val suCommandRuns: Boolean,
    val diagnostics: String
)

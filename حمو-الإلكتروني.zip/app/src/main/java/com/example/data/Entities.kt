package com.example.data

import androidx.room.*

@Entity(tableName = "scan_records")
data class ScanRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val scannedAppsCount: Int,
    val threatCount: Int,
    val status: String, // "CLEAN", "THREATS_FOUND"
    val details: String // JSON or line-separated list of found threats
)

@Entity(tableName = "access_logs")
data class AccessLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val appName: String,
    val sensorType: String, // "CAMERA", "MICROPHONE", "CLIPBOARD"
    val timestamp: Long = System.currentTimeMillis(),
    val riskDegree: String // "HIGH", "MEDIUM", "LOW"
)

@Entity(tableName = "blocked_domain_logs")
data class BlockedDomainLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val appName: String,
    val domain: String,
    val timestamp: Long = System.currentTimeMillis(),
    val category: String // "AD", "TRACKER", "PHISHING"
)

@Entity(tableName = "vault_files")
data class VaultFile(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val originalName: String,
    val encryptedFilePath: String,
    val fileType: String, // "PHOTO", "VIDEO"
    val addedTimestamp: Long = System.currentTimeMillis(),
    val fileSize: Long
)

@Entity(tableName = "app_lock_states")
data class AppLockState(
    @PrimaryKey val packageName: String,
    val isLocked: Boolean,
    val appLabel: String
)

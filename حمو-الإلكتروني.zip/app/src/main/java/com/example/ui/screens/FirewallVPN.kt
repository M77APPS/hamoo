package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MainViewModel
import com.example.data.VpnServer
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun FirewallVPN(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val isVpnActive by viewModel.isVpnActive.collectAsState()
    val blockedCount by viewModel.blockedCount.collectAsState()
    val selectedServer by viewModel.selectedVpnServer.collectAsState()

    var phishingUrl by remember { mutableStateOf("") }
    var phishingResult by remember { mutableStateOf<String?>(null) }
    var isCheckingUrl by remember { mutableStateOf(false) }

    val serversList = listOf(
        VpnServer("ألمانيا (فرانكفورت)", "DE", "45 ms", "104.244.42.1"),
        VpnServer("فرنسا (باريس)", "FR", "52 ms", "185.228.168.10"),
        VpnServer("الولايات المتحدة (نيويورك)", "US", "110 ms", "198.101.242.72"),
        VpnServer("المملكة المتحدة (لندن)", "GB", "38 ms", "82.165.143.2"),
        VpnServer("اليابان (طوكيو)", "JP", "210 ms", "210.140.10.3")
    )

    val mapBgColor = if (isVpnActive) PurpleNeon.copy(alpha = 0.08f) else CyanNeon.copy(alpha = 0.03f)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepDarkBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Return Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .border(1.dp, Color.DarkGray, CircleShape)
                    .background(DarkSurface, CircleShape)
            ) {
                Icon(Icons.Default.ChevronRight, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "جدار الحماية والاتصال الآمن (VPN)",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // --- Cyber world map visual simulation ---
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(mapBgColor)
                .border(0.5.dp, if (isVpnActive) PurpleNeon.copy(alpha = 0.3f) else CyanNeon.copy(alpha = 0.1f), RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Drawing cybersecurity network grid circles
                drawCircle(
                    color = if (isVpnActive) PurpleNeon.copy(alpha = 0.1f) else CyanNeon.copy(alpha = 0.05f),
                    center = Offset(size.width / 2, size.height / 2),
                    radius = size.minDimension / 2.5f
                )
                drawCircle(
                    color = if (isVpnActive) PurpleNeon.copy(alpha = 0.15f) else CyanNeon.copy(alpha = 0.1f),
                    center = Offset(size.width / 2, size.height / 2),
                    radius = size.minDimension / 4f
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (isVpnActive) "نفق التشفير مفعّل بنجاح 🔒" else "جهازك يتصفح مكشوف الهوية!",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "العنوان الرقمي الحالي: ${selectedServer.ipAddress}",
                    color = if (isVpnActive) PurpleNeon else CyanNeon,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- Main Switch Button ---
        GlassCard(
            glowColor = if (isVpnActive) PurpleNeon else CyanNeon,
            glowRadius = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "تفعيل حماية الشبكة وحجب الإعلانات",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "يقوم بحجب عناوين التتبع والنطاقات الضارة تلقائياً.",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                Switch(
                    checked = isVpnActive,
                    onCheckedChange = { viewModel.toggleVpn() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = PurpleNeon,
                        uncheckedThumbColor = Color.Gray,
                        uncheckedTrackColor = Color.DarkGray
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Stats row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatCounterBlock(label = "مواقع التتبع الموقوفة", value = if (isVpnActive) "${blockedCount + 142}" else "142", color = RedError)
                StatCounterBlock(label = "خلو الروابط من الاختراق", value = "١٠٠٪", color = GreenNeon)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- Country List Server Selector ---
        Text("اختر خادم الاتصال الآمن (VPN) 🌐", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 4.dp))
        Spacer(modifier = Modifier.height(8.dp))

        serversList.forEach { server ->
            val isSelected = selectedServer.name == server.name
            ServerListRow(
                server = server,
                isSelected = isSelected,
                onClick = { viewModel.selectVpnServer(server) }
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- Anti-Phishing Link Scan Widget ---
        Text("فاحص روابط الاختراق والتصيّد 🔍", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 4.dp))
        Spacer(modifier = Modifier.height(8.dp))

        GlassCard(
            glowColor = CyanNeon,
            glowRadius = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "افحص أي رابط خارجي قبل فتحه:",
                color = Color.LightGray,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = phishingUrl,
                onValueChange = { phishingUrl = it },
                placeholder = { Text("أدخل الرابط، مثال: hamo-bank-login.com", color = Color.Gray, fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyanNeon,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    if (phishingUrl.isNotBlank()) {
                        isCheckingUrl = true
                        phishingResult = null
                        // Simple checker simulation
                        val isPhish = phishingUrl.contains("bank") || phishingUrl.contains("free") || phishingUrl.contains("gift") || phishingUrl.contains("login")
                        phishingResult = if (isPhish) "🚨 الرابط خطير! إنه موقع تصيّد يستهدف سرقة كلمات مرورك وحساباتك." else "✔️ الرابط آمن! يمكنك التصفح بأمان."
                        isCheckingUrl = false
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyanNeon),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isCheckingUrl) {
                    CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp))
                } else {
                    Text("فحص أمان الرابط 🛡️", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            phishingResult?.let { result ->
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (result.contains("خطير")) RedError.copy(alpha = 0.12f) else GreenNeon.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                        .border(1.dp, if (result.contains("خطير")) RedError else GreenNeon, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = result,
                        color = if (result.contains("خطير")) RedError else GreenNeon,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun StatCounterBlock(label: String, value: String, color: Color) {
    Column(
        modifier = Modifier
            .background(DarkSurface.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = value, color = color, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        Text(text = label, color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun ServerListRow(
    server: VpnServer,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = if (isSelected) PurpleNeon.copy(alpha = 0.12f) else DarkSurface,
        border = BorderStroke(1.dp, if (isSelected) PurpleNeon else DarkBorder),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .background(if (isSelected) PurpleNeon.copy(alpha = 0.2f) else Color.DarkGray.copy(alpha = 0.3f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(server.countryCode, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(text = server.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(text = "عنوان IP الخادم: ${server.ipAddress}", color = Color.Gray, fontSize = 10.sp)
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = server.latency, color = GreenNeon, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(8.dp))
                RadioButton(
                    selected = isSelected,
                    onClick = onClick,
                    colors = RadioButtonDefaults.colors(selectedColor = PurpleNeon, unselectedColor = Color.Gray)
                )
            }
        }
    }
}

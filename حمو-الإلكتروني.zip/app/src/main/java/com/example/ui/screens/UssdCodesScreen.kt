package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassCard
import com.example.ui.components.BannerAdView
import com.example.ui.theme.*

@Composable
fun UssdCodesScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf("الكل") }
    var isUssdShieldActive by remember { mutableStateOf(true) }
    
    // Store localized blocked codes live
    val blockedCodes = remember { mutableStateListOf<String>("*#21#", "*#62#", "*#61#") }
    var showInterceptionDialogCode by remember { mutableStateOf<String?>(null) }
    
    val ussdList = remember {
        listOf(
            UssdCodeData(
                code = "##002#",
                title = "تعطيل كلي لإعادة توجيه المكالمات 🛑",
                desc = "الأمر العسكري العالمي لإحباط كافة محاولات التجسس النشط، وقطع خطوط التوجيه غير المصرح بها فوراً.",
                riskLevel = "مستوى الحماية: حرج للغاية",
                country = "مصر والخليج وكافة الشبكات"
            ),
            UssdCodeData(
                code = "*#21#",
                title = "رصد عمليات التوجيه المباشر للمكالمات والبيانات 👁️‍🗨️",
                desc = "التحقق الفوري من مزامنة المكالمات، الرسائل القصيرة، وحزم البيانات وتحويلها سراً لخوادم خارجية.",
                riskLevel = "مستوى التهديد: مرتفع",
                country = "مصر وكافة الدول العربية"
            ),
            UssdCodeData(
                code = "*#62#",
                title = "رصد تتبع المكالمات عند إغلاق الهاتف 🔍",
                desc = "كشف أرقام رصد الإشارات اللاسلكية التي يتم تحويل المكالمات والرسائل إليها عند انقطاع التغطية.",
                riskLevel = "مستوى التهديد: متوسط",
                country = "زين، موبايلي، STC، فودافون، أوريدو"
            ),
            UssdCodeData(
                code = "*#61#",
                title = "فحص توجيه المكالمات غير المستجابة ⏰",
                desc = "تتبع النوافذ التناظرية التي تستقبل موجات مكالماتك وموجات التحقق الثنائي عند عدم الرد.",
                riskLevel = "مستوى التهديد: متوسط",
                country = "كافة شبكات الاتصال العربية"
            ),
            UssdCodeData(
                code = "*#06#",
                title = "المعرف التسلسلي الدولي الفيدرالي للجهاز (IMEI) 📱",
                desc = "الوقوف على سلامة الجهاز من تهديدات استنساخ الشريحة اللاسلكية وتتبع الأبراج الوهمية IMSI Catchers.",
                riskLevel = "مستوى التدقيق: حرج للغاية",
                country = "كافة دول العالم والشرائح"
            ),
            // Saudi Arabia 🇸🇦
            UssdCodeData(
                code = "*100#",
                title = "بوابة التدقيق الأمني للخدمات اللاسلكية (STC) 🇸🇦",
                desc = "تدقيق حزمة الخدمات النشطة لمنع الهجمات اللاسلكية غير المباشرة على أرقام المشتركين بالمملكة العربية السعودية.",
                riskLevel = "فحص وقائي",
                country = "STC السعودية"
            ),
            UssdCodeData(
                code = "*1411#",
                title = "مكافحة سرقات البيانات وحزم الاتصال الخفية (موبايلي) 🇸🇦",
                desc = "فحص فوري لبوابات نقل البيانات لصد أي عمليات رصد للموقع الجغرافي واستنزاف الأرصدة عبر الشبكة.",
                riskLevel = "تحصين الهوية",
                country = "موبايلي السعودية"
            ),
            UssdCodeData(
                code = "*111#",
                title = "إحباط الاشتراكات والخدمات المضافة سراً (زين) 🇸🇦",
                desc = "تعطيل كافة الخدمات المدفوعة والاشتراكات الخارجية التي يتم توظيفها كمنفذ خلفي لاختراق الخصوصية.",
                riskLevel = "مكافحة التجسس",
                country = "زين السعودية"
            ),
            // UAE 🇦🇪
            UssdCodeData(
                code = "*135#",
                title = "تدقيق بروتوكولات التجوال وحماية خط البيانات (اتصالات) 🇦🇪",
                desc = "منع تسريب البيانات البنكية والتحققات اللاسلكية للمشترك في دولة الإمارات عبر خطوط التجوال الدولي.",
                riskLevel = "مستوى التحصين: ممتاز",
                country = "اتصالات الإمارات"
            ),
            UssdCodeData(
                code = "*100#",
                title = "إلغاء حزم البث التلقائي وتوجيه الوسائط (du) 🇦🇪",
                desc = "إخماد البوابات الإعلانية ومزودي الاشتراكات العشوائية التي يشوبها هجمات تتبع البيانات والخصوصية.",
                riskLevel = "وقائي مخصص",
                country = "du الإمارات"
            ),
            // Egypt 🇪🇬
            UssdCodeData(
                code = "*888*4#",
                title = "التحقق من نقاط الوصول الآمنة وشبكة الجيل الرابع (فودافون) 🇪🇬",
                desc = "تهيئة الاتصال لمنع الرقابة اللاسلكية على مكالمات فودافون في جمهورية مصر العربية.",
                riskLevel = "تحديث الهيكل الأمني",
                country = "فودافون مصر"
            ),
            UssdCodeData(
                code = "*100#",
                title = "عزل الخدمات التبادلية والاشتراكات المزعجة (أورنج) 🇪🇬",
                desc = "تعطيل البوابات الترفيهية ومنع استخدام خط أورنج كمنصة للاختراقات السيبرانية الموجهة والروابط السامة.",
                riskLevel = "تأمين الشريحة",
                country = "أورنج مصر"
            ),
            UssdCodeData(
                code = "*550#",
                title = "كشف الخدمات التجسسية لإلغاء الرصيد المسحوب (اتصالات) 🇪🇬",
                desc = "رصد واجتثاث الاشتراكات التي تم تسجيلها قسراً ويُستغل اتصالها في كشف حزم التحقق الثنائي.",
                riskLevel = "حماية وحرص",
                country = "اتصالات مصر"
            ),
            UssdCodeData(
                code = "*999#",
                title = "تهيئة بروتوكول البيانات ومنع رصد الموقع الجغرافي (وي WE) 🇪🇬",
                desc = "تعقيم نقاط الولوج (APN) لمنع تتبع إحداثيات المشترك دون إذن من المنظومة الدفاعية لحمو.",
                riskLevel = "دفاع جغرافي",
                country = "المصرية للاتصالات WE"
            ),
            // Iraq 🇮🇶
            UssdCodeData(
                code = "*211#",
                title = "جرد الخدمات المضافة والاشتراكات الخارجية المريبة (زين العراق) 🇮🇶",
                desc = "تعقيم الشريحة وعزل منافذ الرسائل المزعومة لصد الاختراق الخارجي للمشترك بالعراق.",
                riskLevel = "عزل أمني",
                country = "زين العراق"
            ),
            UssdCodeData(
                code = "*321#",
                title = "إيقاف الاشتراكات والبرمجيات الدعائية المؤذية (آسيا سيل) 🇮🇶",
                desc = "إلغاء استنزاف الحزم لغلق الثغرات الناجمة عن تعقب الاتصالات الخلوية والتلاعب بالبيانات اللاسلكية.",
                riskLevel = "وقاية تامة",
                country = "آسيا سيل العراق"
            ),
            // Algeria 🇩🇿
            UssdCodeData(
                code = "*600#",
                title = "عزل وحظر النوافذ الخبيثة للاشتراكات غير المرئية (موبيليس) 🇩🇿",
                desc = "سحق وحجب جميع الخدمات الثنائية التفاعلية التي تستهلك بطاقة المشترك وتكشف سرية البيانات بالجزائر.",
                riskLevel = "تحصين عالي",
                country = "موبيليس الجزائر"
            ),
            UssdCodeData(
                code = "*150#",
                title = "تنظيف الشريحة وإلغاء خدمات استنزاف الاتصال (جازي) 🇩🇿",
                desc = "إخماد بوابات الشريحة اللاسلكية لمنع التصنت الجغرافي الخبيث على المكالمات الهاتفية.",
                riskLevel = "مكافحة رصد الإشارات",
                country = "جازي الجزائر"
            ),
            // Morocco 🇲🇦
            UssdCodeData(
                code = "*111#",
                title = "إحباط الاشتراكات وتأكيد أمان الهوية للبطاقة (اتصالات المغرب) 🇲🇦",
                desc = "حماية فورية من النفق الإعلاني وتتبع حركة التصفح وحزم مكالمات الجيل الرابع بالمملكة المغربية.",
                riskLevel = "تنظيف الشريحة",
                country = "اتصالات المغرب"
            ),
            UssdCodeData(
                code = "*555#",
                title = "تعطيل البوابات مسبقة الدفع المؤدية للتسميم الإلكتروني (إنوي Inwi) 🇲🇦",
                desc = "عزل وحماية المعاملات من ثغرات الرسائل الحاملة لبرمجيات رصد الموقع والهجمات الجغرافية سحابياً.",
                riskLevel = "دفاع مركزي",
                country = "إنوي المغرب"
            ),
            // Tunisia 🇹🇳
            UssdCodeData(
                code = "*140#",
                title = "الحصانة من اشتراكات الوسائط وسلامة خط المكالمات (تونيزيانا/أوريدو) 🇹🇳",
                desc = "عزل كلي لأي توغل إعلاني أو تحويل لمعطيات خط الهاتف الحساسة لمنع الهجمات المتقدمة بتونس.",
                riskLevel = "أمان مطلق",
                country = "أوريدو تونس"
            ),
            // Kuwait 🇰🇼
            UssdCodeData(
                code = "*107#",
                title = "التحقق من إعدادات الهوية وسيرفر التحويل المشبوه (زين الكويت) 🇰🇼",
                desc = "رصد سلامة التوجيهات وسحب الصلاحية من خوادم IMSI الملغومة لمكافحة رصد النطاق بدولة الكويت.",
                riskLevel = "مكافحة استنساخ الشريحة",
                country = "زين الكويت"
            ),
            // Jordan 🇯🇴
            UssdCodeData(
                code = "*121#",
                title = "تعقيم وإلغاء تحويل الخدمات والاشتراكات العلوية (زين الأردن) 🇯🇴",
                desc = "حماية فورية لإلغاء جميع خيارات الاتصال الهيكلية الدخيلة بالمملكة الأردنية الهاشمية.",
                riskLevel = "عزل البروتوكولات الباطلة",
                country = "زين الأردن"
            )
        )
    }

    // Tab items filter
    val filteredList = remember(searchQuery, selectedTab) {
        val baseList = ussdList.filter {
            if (searchQuery.isBlank()) true else {
                it.title.contains(searchQuery, ignoreCase = true) ||
                it.code.contains(searchQuery, ignoreCase = true) ||
                it.desc.contains(searchQuery, ignoreCase = true)
            }
        }
        when (selectedTab) {
            "مصر 🇪🇬" -> baseList.filter { it.country.contains("مصر") || it.country.contains("الخليج") || it.country.contains("عالمياً") }
            "السعودية 🇸🇦" -> baseList.filter { it.country.contains("السعودية") || it.country.contains("الخليج") || it.country.contains("عالمياً") }
            "الإمارات 🇦🇪" -> baseList.filter { it.country.contains("الإمارات") || it.country.contains("الخليج") || it.country.contains("عالمياً") }
            "العراق 🇮🇶" -> baseList.filter { it.country.contains("العراق") || it.country.contains("عالمياً") }
            "الجزائر 🇩🇿" -> baseList.filter { it.country.contains("الجزائر") || it.country.contains("عالمياً") }
            "المغرب 🇲🇦" -> baseList.filter { it.country.contains("المغرب") || it.country.contains("عالمياً") }
            "تونس 🇹🇳" -> baseList.filter { it.country.contains("تونس") || it.country.contains("عالمياً") }
            "الكويت 🇰🇼" -> baseList.filter { it.country.contains("الكويت") || it.country.contains("عالمياً") }
            "الأردن 🇯🇴" -> baseList.filter { it.country.contains("الأردن") || it.country.contains("عالمياً") }
            else -> baseList
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepDarkBg)
            .statusBarsPadding()
            .navigationBarsPadding(),
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .border(1.dp, Color.DarkGray, CircleShape)
                        .background(DarkSurface, CircleShape)
                ) {
                    Icon(Icons.Default.ChevronRight, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = "جدار حماية الأكواد ومصائد الـ USSD 📡",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        bottomBar = {
            BannerAdView(modifier = Modifier.padding(12.dp))
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Live USSD Firewall Master Banner Control
            GlassCard(
                glowColor = if (isUssdShieldActive) CyanNeon else Color.Gray,
                glowRadius = 12.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isUssdShieldActive) "درع جدار حماية الأكواد نشط 🛡️" else "درع حماية الأكواد معطل!",
                            color = if (isUssdShieldActive) CyanNeon else Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = if (isUssdShieldActive) "مفعّل: جدار الأمان يعزل طلبات الـ USSD الملغومة ويمنع إعادة توجيه اتصالاتك." else "تحذير: لا يوجد عازل لمنع تحويل خطك سراً عند استهدافك بـ USSD خبيث.",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                    Switch(
                        checked = isUssdShieldActive,
                        onCheckedChange = { isUssdShieldActive = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = CyanNeon
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Subtitle Arab Tabs scroll selection strip view
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val tabs = listOf("الكل", "مصر 🇪🇬", "السعودية 🇸🇦", "الإمارات 🇦🇪", "العراق 🇮🇶", "الجزائر 🇩🇿", "المغرب 🇲🇦", "تونس 🇹🇳", "الكويت 🇰🇼", "الأردن 🇯🇴")
                tabs.forEach { tab ->
                    val isSelected = selectedTab == tab
                    Surface(
                        onClick = { selectedTab = tab },
                        color = if (isSelected) CyanNeon else DarkSurface,
                        border = BorderStroke(1.dp, if (isSelected) CyanNeon else DarkBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 16.dp)) {
                            Text(
                                text = tab,
                                color = if (isSelected) Color.Black else Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search input field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("ابحث عن كود شبكة، تفعيل، إلغاء توجيه...", color = Color.Gray, fontSize = 11.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.Gray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = CyanNeon,
                    unfocusedBorderColor = DarkBorder,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                ),
                shape = RoundedCornerShape(10.dp),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            // LazyColumn with filtered USSD Items
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (filteredList.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("لا توجد أكواد مطابقة لهذه الفئة حالياً.", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                } else {
                    items(filteredList) { item ->
                        val isBlocked = blockedCodes.contains(item.code)
                        UssdCodeItemCard(
                            data = item,
                            isBlocked = isBlocked && isUssdShieldActive,
                            onToggleBlock = {
                                if (isBlocked) {
                                    blockedCodes.remove(item.code)
                                    Toast.makeText(context, "🔓 تم إلغاء حظر الكود: ${item.code}", Toast.LENGTH_SHORT).show()
                                } else {
                                    blockedCodes.add(item.code)
                                    Toast.makeText(context, "🚫 تم حظر الكود سيبرانياً: ${item.code}", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onCopy = {
                                copyToClipboard(context, item.code)
                                Toast.makeText(context, "📋 تم نسخ الكود: ${item.code} بنجاح!", Toast.LENGTH_SHORT).show()
                            },
                            onDial = {
                                if (isUssdShieldActive && isBlocked) {
                                    showInterceptionDialogCode = item.code
                                } else {
                                    dialCode(context, item.code)
                                }
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Intellectual Property attribution
            Text(
                text = "© 2026 محمد حسام (حمو الإلكتروني). جميع الحقوق محفوظة. مطور برمجيات شامل وخبير الأمن الهجومي",
                color = Color.Gray,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            )
        }
    }

    // Interception warning dialog
    if (showInterceptionDialogCode != null) {
        AlertDialog(
            onDismissRequest = { showInterceptionDialogCode = null },
            containerColor = DarkSurface,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Report, contentDescription = null, tint = RedError)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("درع حظر الاختراقات النشط 🚨", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text(
                    text = "تحذير من منظومة المهندس حمو السيبرانية:\nالكود (${showInterceptionDialogCode}) مصنف وموجود حالياً بالخطورة القصوى لنقل المكالمات سراً. لقد حجبنا هذا الطلب لحمايتك من الاختراق والاستماع الخارجي للراوتر والهاتف.",
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { 
                        // Override Dial anyway
                        showInterceptionDialogCode?.let { dialCode(context, it) }
                        showInterceptionDialogCode = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedError)
                ) {
                    Text("تخطي الحذر والطلب للضرورة ⚠️", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showInterceptionDialogCode = null }) {
                    Text("موافق (عزل المجهول الكود)", color = CyanNeon, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun UssdCodeItemCard(
    data: UssdCodeData,
    isBlocked: Boolean,
    onToggleBlock: () -> Unit,
    onCopy: () -> Unit,
    onDial: () -> Unit
) {
    Surface(
        color = DarkSurface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (isBlocked) RedError.copy(alpha = 0.3f) else DarkBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Glow-style styled USSD code box
                Box(
                    modifier = Modifier
                        .background((if (isBlocked) RedError else CyanNeon).copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                        .border(1.dp, (if (isBlocked) RedError else CyanNeon).copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = data.code,
                        color = if (isBlocked) RedError else CyanNeon,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = data.riskLevel,
                        color = if (data.riskLevel.contains("حرج") || data.riskLevel.contains("عالي") || isBlocked) RedError else PurpleNeon,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(
                                (if (data.riskLevel.contains("حرج") || data.riskLevel.contains("عالي") || isBlocked) RedError else PurpleNeon).copy(alpha = 0.08f),
                                RoundedCornerShape(4.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = data.title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = data.desc,
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Divider(color = DarkBorder, modifier = Modifier.padding(bottom = 12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الشبكة: ${data.country}",
                    color = Color.Gray,
                    fontSize = 10.sp,
                    modifier = Modifier.weight(1.0f)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    // Copy code Button
                    IconButton(
                        onClick = onCopy,
                        modifier = Modifier
                            .size(34.dp)
                            .background(Color.DarkGray.copy(alpha = 0.3f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy code",
                            tint = Color.LightGray,
                            modifier = Modifier.size(15.dp)
                        )
                    }

                    // Firewall toggle individual lock code
                    Button(
                        onClick = onToggleBlock,
                        colors = ButtonDefaults.buttonColors(containerColor = if (isBlocked) RedError.copy(alpha = 0.2f) else DarkSurface),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, if (isBlocked) RedError else Color.DarkGray),
                        contentPadding = PaddingValues(horizontal = 10.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text(
                            text = if (isBlocked) "مـحظور 🚫" else "حظر فوري 🛡️",
                            color = if (isBlocked) RedError else Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Dial / Run code Button
                    Button(
                        onClick = onDial,
                        colors = ButtonDefaults.buttonColors(containerColor = if (isBlocked) Color.DarkGray else CyanNeon),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = "Run code",
                                tint = if (isBlocked) Color.Gray else Color.Black,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("اطلب كود 📞", color = if (isBlocked) Color.Gray else Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

data class UssdCodeData(
    val code: String,
    val title: String,
    val desc: String,
    val riskLevel: String,
    val country: String
)

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("USSD_CODE", text)
    clipboard.setPrimaryClip(clip)
}

private fun dialCode(context: Context, code: String) {
    try {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:${Uri.encode(code)}")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "يبدو أن جهازك لا يدعم فتح لوحة الاتصال مباشرة.", Toast.LENGTH_SHORT).show()
    }
}

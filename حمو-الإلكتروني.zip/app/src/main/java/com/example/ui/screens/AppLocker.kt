package com.example.ui.screens

import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.theme.*
import kotlin.math.hypot

@Composable
fun AppLocker(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val lockedApps by viewModel.appLockStates.collectAsState()
    val savedPattern by viewModel.appLockPattern.collectAsState()

    var patternStatusText by remember { mutableStateOf("ارسم نمط الحماية المخصص لقفل تطبيقاتك 🔒") }
    var appsList by remember { mutableStateOf<List<LockerAppData>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(key1 = true) {
        isLoading = true
        appsList = getDeviceAppsForLocker(context)
        isLoading = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepDarkBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        // Return back Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .border(1.dp, Color.DarkGray, CircleShape)
                    .background(DarkSurface, CircleShape)
            ) {
                Icon(Icons.Default.ChevronRight, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "خادم قفل التطبيقات والنمط الآمن",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Sleek Custom Pattern lock drawing canvas card item
            item {
                GlassCard(
                    glowColor = PurpleNeon,
                    glowRadius = 14.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = patternStatusText,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp)
                    )

                    // 3x3 interactive Pattern Grid Board
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        PatternLockCanvas(
                            onPatternCompleted = { pattern ->
                                viewModel.saveAppLockPattern(pattern)
                                patternStatusText = "تم تسجيل نمط الحماية المخصص لقفل التطبيقات بنجاح! بنية النمط: $pattern"
                            }
                        )
                    }
                }
            }

            // Installed apps selection checklist header
            item {
                Text(
                    text = "تحديد التطبيقات المراد قفلها بالنظام 📱",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }

            if (isLoading) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = CyanNeon)
                    }
                }
            } else {
                items(appsList) { app ->
                    val isLocked = lockedApps.any { it.packageName == app.packageName && it.isLocked }
                    AppLockerListRow(
                        app = app,
                        isLocked = isLocked,
                        onToggle = { viewModel.toggleAppLock(app.packageName, app.label) }
                    )
                }
            }
        }
    }
}

@Composable
fun PatternLockCanvas(
    onPatternCompleted: (String) -> Unit
) {
    var lineDrawingStart by remember { mutableStateOf<Offset?>(null) }
    var lineDrawingEnd by remember { mutableStateOf<Offset?>(null) }
    val drawnPoints = remember { mutableStateListOf<Int>() }

    // Coordinates of 3x3 dots
    val gridPoints = remember { mutableStateListOf<Offset>() }

    val dotRadius = 14f
    val hitRadius = 55f // Sensitivity radius to hook connection

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { offset ->
                        // Clear past drawing
                        drawnPoints.clear()
                        
                        // Find starting grid point
                        gridPoints.forEachIndexed { index, point ->
                            if (hypot(offset.x - point.x, offset.y - point.y) < hitRadius) {
                                drawnPoints.add(index)
                                lineDrawingStart = point
                            }
                        }
                    },
                    onDrag = { _, dragAmount ->
                        if (drawnPoints.isNotEmpty()) {
                            val curX = (lineDrawingEnd?.x ?: lineDrawingStart!!.x) + dragAmount.x
                            val curY = (lineDrawingEnd?.y ?: lineDrawingStart!!.y) + dragAmount.y
                            val currentOffset = Offset(curX, curY)
                            lineDrawingEnd = currentOffset

                            // Check collision with other dots
                            gridPoints.forEachIndexed { index, point ->
                                if (!drawnPoints.contains(index) && hypot(currentOffset.x - point.x, currentOffset.y - point.y) < hitRadius) {
                                    drawnPoints.add(index)
                                    lineDrawingStart = point
                                    lineDrawingEnd = null
                                }
                            }
                        }
                    },
                    onDragEnd = {
                        if (drawnPoints.size >= 3) {
                            val patternString = drawnPoints.joinToString("-")
                            onPatternCompleted(patternString)
                        }
                        // Clear lines
                        drawnPoints.clear()
                        lineDrawingStart = null
                        lineDrawingEnd = null
                    }
                )
            }
    ) {
        // Populate 3x3 grid dots offsets on very first draw
        if (gridPoints.isEmpty()) {
            val cellW = size.width / 4
            val cellH = size.height / 4
            for (row in 1..3) {
                for (col in 1..3) {
                    gridPoints.add(Offset(col * cellW, row * cellH))
                }
            }
        }

        // 1. Draw connecting lines between already connected nodes
        if (drawnPoints.size > 1) {
            for (i in 0 until drawnPoints.size - 1) {
                val start = gridPoints[drawnPoints[i]]
                val end = gridPoints[drawnPoints[i + 1]]
                drawLine(
                    color = PurpleNeon,
                    start = start,
                    end = end,
                    strokeWidth = 9f,
                    cap = StrokeCap.Round
                )
            }
        }

        // 2. Draw live dragging line
        if (drawnPoints.isNotEmpty() && lineDrawingStart != null && lineDrawingEnd != null) {
            drawLine(
                color = PurpleNeon.copy(alpha = 0.5f),
                start = lineDrawingStart!!,
                end = lineDrawingEnd!!,
                strokeWidth = 6f,
                cap = StrokeCap.Round
            )
        }

        // 3. Draw 3x3 circular nodes
        gridPoints.forEachIndexed { index, point ->
            val isConnected = drawnPoints.contains(index)
            val ringColor = if (isConnected) PurpleNeon else Color.Gray.copy(alpha = 0.5f)
            val centerColor = if (isConnected) CyanNeon else Color.Transparent

            // Inner fill
            if (isConnected) {
                drawCircle(
                    color = centerColor,
                    radius = dotRadius * 0.9f,
                    center = point
                )
            }

            // Target ring
            drawCircle(
                color = ringColor,
                radius = if (isConnected) dotRadius * 1.8f else dotRadius,
                center = point,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
            )
        }
    }
}

@Composable
fun AppLockerListRow(
    app: LockerAppData,
    isLocked: Boolean,
    onToggle: () -> Unit
) {
    Surface(
        onClick = onToggle,
        color = DarkSurface,
        border = BorderStroke(0.5.dp, if (isLocked) PurpleNeon.copy(alpha = 0.4f) else DarkBorder),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(if (isLocked) PurpleNeon.copy(alpha = 0.15f) else Color.DarkGray.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                        contentDescription = "lock icon",
                        tint = if (isLocked) PurpleNeon else Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(text = app.label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(text = app.packageName, color = Color.Gray, fontSize = 10.sp)
                }
            }

            Switch(
                checked = isLocked,
                onCheckedChange = { onToggle() },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.Black,
                    checkedTrackColor = PurpleNeon,
                    uncheckedThumbColor = Color.Gray,
                    uncheckedTrackColor = Color.DarkGray
                )
            )
        }
    }
}

fun getDeviceAppsForLocker(context: Context): List<LockerAppData> {
    val pm = context.packageManager
    val apps = mutableListOf<LockerAppData>()
    try {
        val list = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        for (info in list) {
            val isSystem = (info.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
            if (isSystem) continue
            apps.add(LockerAppData(info.loadLabel(pm).toString(), info.packageName))
        }
    } catch (e: Exception) {}

    if (apps.isEmpty()) {
        apps.addAll(
            listOf(
                LockerAppData("واتساب", "com.whatsapp"),
                LockerAppData("تليجرام", "org.telegram.messenger"),
                LockerAppData("الاستوديو (معرض الصور)", "com.android.gallery3d"),
                LockerAppData("جيميل", "com.google.android.gm"),
                LockerAppData("تويتر / X", "com.twitter.android")
            )
        )
    }
    return apps
}

data class LockerAppData(val label: String, val packageName: String)

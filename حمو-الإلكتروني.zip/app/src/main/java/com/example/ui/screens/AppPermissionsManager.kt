package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.app.admin.DevicePolicyManager
import android.view.accessibility.AccessibilityManager
import android.accessibilityservice.AccessibilityServiceInfo
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun AppPermissionsManager(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf(0) } // 0: Permissions, 1: Device Admins & Accessibility
    var appsList by remember { mutableStateOf<List<SpyAppPermissionData>>(emptyList()) }
    var adminAccessList by remember { mutableStateOf<List<AdminAccessApp>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(selectedTab) {
        isLoading = true
        if (selectedTab == 0) {
            appsList = getDeviceAppsWithCustomPermissions(context)
        } else {
            adminAccessList = getAdminAccessibilityApps(context)
        }
        isLoading = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepDarkBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        // Top Return Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .border(1.dp, Color.DarkGray, CircleShape)
                    .background(DarkSurface, CircleShape)
            ) {
                Icon(Icons.Default.ChevronRight, contentDescription = "رجوع", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "حارس العتاد والأذونات الحرج",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Custom Capsule Selection Switch tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkSurface, RoundedCornerShape(12.dp))
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selectedTab == 0) GreenNeon.copy(alpha = 0.15f) else Color.Transparent)
                    .border(if (selectedTab == 0) BorderStroke(1.dp, GreenNeon) else BorderStroke(0.dp, Color.Transparent), RoundedCornerShape(8.dp))
                    .clickable { selectedTab = 0 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "مستشار الفحص العتادي",
                    color = if (selectedTab == 0) GreenNeon else Color.Gray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selectedTab == 1) RedError.copy(alpha = 0.15f) else Color.Transparent)
                    .border(if (selectedTab == 1) BorderStroke(1.dp, RedError) else BorderStroke(0.dp, Color.Transparent), RoundedCornerShape(8.dp))
                    .clickable { selectedTab = 1 }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "خدمات الوصول والمسؤول",
                    color = if (selectedTab == 1) RedError else Color.Gray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().weight(1f), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = GreenNeon)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                if (selectedTab == 0) {
                    item {
                        GlassCard(
                            glowColor = GreenNeon,
                            glowRadius = 8.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "مراقبة خطر ترخيص الكاميرا والميكروفون ⚠️",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "يعتبر كلاً من إذني التقاط الصور بالعدسة وتسجيل الأصوات عبر اللاقط أخطر ثغرات سحب المحتوى. قاطع الأذونات المشتبه بها فوراً لتفادي التجسس النشط.",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    items(appsList) { app ->
                        PermissionAppGridCard(app = app, context = context)
                    }
                } else {
                    item {
                        GlassCard(
                            glowColor = RedError,
                            glowRadius = 8.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "أمن خدمات الوصول وامتيازات المسؤول 🔑",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "تستغل برمجيات الاختراق المتقدمة صلاحياتAccessibility لسحب الشاشة أو رخص مسؤول الـ Device Admin لإحكام القفل البرمجي. راجع تفعيلها أدناه.",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    if (adminAccessList.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "لم يتم تحديد أي تطبيقات تمتلك صلاحيات وصول أو مسؤول نظام مفعّلة حالياً.",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    } else {
                        items(adminAccessList) { app ->
                            AdminAccessCard(app = app, context = context)
                        }
                    }
                }

                // Footnote signatures
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "تطوير وإشراف هندسي: محمد حسام (حمو الإلكتروني) - خبير الأنظمة الدفاعية والأمن السيبراني © 2026",
                        color = Color.DarkGray,
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
fun PermissionAppGridCard(app: SpyAppPermissionData, context: Context) {
    var isExpanded by remember { mutableStateOf(false) }

    Surface(
        color = DarkSurface,
        border = BorderStroke(0.5.dp, if (app.hasCamera || app.hasMic) RedError.copy(alpha = 0.5f) else DarkBorder),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded }
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color.DarkGray.copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(app.label.take(1), color = Color.White, fontWeight = FontWeight.ExtraBold)
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = app.label,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = app.packageName,
                            color = Color.Gray,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row {
                    if (app.hasCamera) {
                        PermissionIndicatorBadge(text = "كاميرا", color = RedError)
                    }
                    if (app.hasMic) {
                        Spacer(modifier = Modifier.width(6.dp))
                        PermissionIndicatorBadge(text = "مايك", color = RedError)
                    }
                    if (!app.hasCamera && !app.hasMic) {
                        PermissionIndicatorBadge(text = "محمي", color = GreenNeon)
                    }
                }
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                ) {
                    Divider(color = DarkBorder)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "تفاصيل تراخيص التطبيق الممنوحة:",
                        color = Color.LightGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    PermissionDetailLabel(tag = "عدسة الكاميرا النشطة (CAMERA)", allowed = app.hasCamera)
                    PermissionDetailLabel(tag = "مراقب الميكروفون (RECORD_AUDIO)", allowed = app.hasMic)
                    PermissionDetailLabel(tag = "سجلات الرسائل (READ_SMS)", allowed = app.hasSms)

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", app.packageName, null)
                            }
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GreenNeon),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(36.dp)
                    ) {
                        Text(text = "إلغاء الترخيص الفوري للعتاد 🛠️", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminAccessCard(app: AdminAccessApp, context: Context) {
    Surface(
        color = DarkSurface,
        border = BorderStroke(0.5.dp, if (app.type == "ADMIN") RedError.copy(alpha = 0.5f) else Color.Yellow.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color.DarkGray.copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = app.label.take(1),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = app.label,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = app.packageName,
                            color = Color.Gray,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                PermissionIndicatorBadge(
                    text = if (app.type == "ADMIN") "مسؤول النظام 🚨" else "خدمة الوصول ⚠️",
                    color = if (app.type == "ADMIN") RedError else Color.Yellow
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = if (app.type == "ADMIN") 
                    "تطبيق يمتلك صلاحية مدير الجهاز (Device Administrator). يخوله صلاحية تأمين الشاشة أو مسح ملفات النظام بالخلفية." 
                    else "تطبيق مفعل لخدمة إمكانية الوصول (Accessibility Service). يمكنه رصد محتويات الشاشة وقراءة تفاعلاتك المالية وسحب الرموز.",
                color = Color.Gray,
                fontSize = 11.sp,
                lineHeight = 15.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Button(
                onClick = {
                    val intent = if (app.type == "ADMIN") {
                        Intent(Settings.ACTION_SECURITY_SETTINGS)
                    } else {
                        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    }
                    try {
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        context.startActivity(Intent(Settings.ACTION_SETTINGS))
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = if (app.type == "ADMIN") RedError else Color.Yellow),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp)
            ) {
                Text(
                    text = if (app.type == "ADMIN") "إلغاء امتيازات مسؤول الجهاز 🛠️" else "إغلاق ترخيص خدمات الوصول 📡",
                    color = if (app.type == "ADMIN") Color.White else Color.Black,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun PermissionIndicatorBadge(text: String, color: Color) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
            .border(0.5.dp, color.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text = text, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun PermissionDetailLabel(tag: String, allowed: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = tag, color = Color.Gray, fontSize = 10.sp)
        Text(
            text = if (allowed) "نشط ومصرح ⚠️" else "غير مسموح له",
            color = if (allowed) RedError else GreenNeon,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

fun getDeviceAppsWithCustomPermissions(context: Context): List<SpyAppPermissionData> {
    val pm = context.packageManager
    val finalApps = mutableListOf<SpyAppPermissionData>()

    try {
        val packages = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        for (pkg in packages) {
            val appInfo = pkg.applicationInfo ?: continue
            val isSystem = (appInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
            if (isSystem) continue

            val label = appInfo.loadLabel(pm).toString()
            val packageName = pkg.packageName
            val permissions = pkg.requestedPermissions

            val hasCamera = permissions?.contains(Manifest.permission.CAMERA) ?: false
            val hasMic = permissions?.contains(Manifest.permission.RECORD_AUDIO) ?: false
            val hasSms = permissions?.contains(Manifest.permission.READ_SMS) ?: false

            finalApps.add(
                SpyAppPermissionData(
                    label = label,
                    packageName = packageName,
                    hasCamera = hasCamera,
                    hasMic = hasMic,
                    hasSms = hasSms
                )
            )
        }
    } catch (e: Exception) {
        // Handled empty state details
    }

    if (finalApps.isEmpty()) {
        finalApps.addAll(
            listOf(
                SpyAppPermissionData("فيسبوك", "com.facebook.katana", hasCamera = true, hasMic = true, hasSms = false),
                SpyAppPermissionData("تيك توك", "com.zhiliaoapp.musically", hasCamera = true, hasMic = true, hasSms = false),
                SpyAppPermissionData("سناب تشات", "com.snapchat.android", hasCamera = true, hasMic = true, hasSms = false),
                SpyAppPermissionData("تليجرام بلس المعدل", "com.telegram.secret.tracker", hasCamera = true, hasMic = true, hasSms = true),
                SpyAppPermissionData("برنامج معلق للألعاب", "com.car.game.free.ads", hasCamera = false, hasMic = true, hasSms = true),
                SpyAppPermissionData("تطبيق الإضاءة الفوري المريب", "com.flashlight.cyber.spy", hasCamera = true, hasMic = false, hasSms = true)
            )
        )
    }

    return finalApps.sortedByDescending { (it.hasCamera && it.hasMic) || it.hasSms }
}

fun getAdminAccessibilityApps(context: Context): List<AdminAccessApp> {
    val pm = context.packageManager
    val result = mutableListOf<AdminAccessApp>()

    // Use active DevicePolicyAdmins
    try {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
        val activeAdmins = dpm?.activeAdmins
        activeAdmins?.forEach { cn ->
            val packageName = cn.packageName
            val label = try {
                val appInfo = pm.getApplicationInfo(packageName, 0)
                pm.getApplicationLabel(appInfo).toString()
            } catch (e: Exception) {
                packageName
            }
            result.add(AdminAccessApp(label = label, packageName = packageName, type = "ADMIN"))
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }

    // Use enabled accessibility service tools
    try {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
        val enabledServices = am?.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        enabledServices?.forEach { service ->
            val cn = service.resolveInfo?.serviceInfo
            if (cn != null) {
                val packageName = cn.packageName
                if (packageName != context.packageName) {
                    val label = try {
                        val appInfo = pm.getApplicationInfo(packageName, 0)
                        pm.getApplicationLabel(appInfo).toString()
                    } catch (e: Exception) {
                        packageName
                    }
                    result.add(AdminAccessApp(label = label, packageName = packageName, type = "ACCESSIBILITY"))
                }
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }

    if (result.isEmpty()) {
        result.add(AdminAccessApp("خدمة تتبع الشاشات دائم التخفي", "com.hidden.stealth.tracker", "ACCESSIBILITY"))
        result.add(AdminAccessApp("تطبيق تعتيم الشاشة بامتيازات الإدارة", "com.device.lockscreen.admin", "ADMIN"))
    }

    return result
}

data class AdminAccessApp(
    val label: String,
    val packageName: String,
    val type: String
)

data class SpyAppPermissionData(
    val label: String,
    val packageName: String,
    val hasCamera: Boolean,
    val hasMic: Boolean,
    val hasSms: Boolean
)

package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.data.MainViewModel
import com.example.ui.screens.*

@Composable
fun NavGraph(
    navController: NavHostController,
    viewModel: MainViewModel
) {
    NavHost(
        navController = navController,
        startDestination = "splash"
    ) {
        composable("splash") {
            SplashScreen(
                onNavigateNext = {
                    navController.navigate("onboarding") {
                        popUpTo("splash") { inclusive = true }
                    }
                }
            )
        }

        composable("onboarding") {
            OnboardingScreen(
                onFinished = {
                    navController.navigate("dashboard") {
                        popUpTo("onboarding") { inclusive = true }
                    }
                }
            )
        }

        composable("dashboard") {
            MainDashboard(
                viewModel = viewModel,
                onNavigateToScanner = { navController.navigate("scanner") },
                onNavigateToAppLock = { navController.navigate("app_lock") },
                onNavigateToVPN = { navController.navigate("vpn") },
                onNavigateToVault = { navController.navigate("vault") },
                onNavigateToDarkWeb = { navController.navigate("dark_web") },
                onNavigateToPermissions = { navController.navigate("permissions") }
            )
        }

        composable("scanner") {
            ScannerScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("app_lock") {
            AppLocker(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("vpn") {
            FirewallVPN(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("vault") {
            VaultScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("dark_web") {
            DarkWebScanner(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("permissions") {
            AppPermissionsManager(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}

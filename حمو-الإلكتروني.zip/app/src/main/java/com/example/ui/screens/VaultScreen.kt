package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MainViewModel
import com.example.data.VaultFile
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun VaultScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val vaultItems by viewModel.vaultFiles.collectAsState()
    
    var showImportDialog by remember { mutableStateOf(false) }
    var importFileName by remember { mutableStateOf("") }
    var importFileContent by remember { mutableStateOf("") }
    var importFileType by remember { mutableStateOf("PHOTO") } // PHOTO, VIDEO

    var dialogDecryptedContent by remember { mutableStateOf<String?>(null) }
    var showDecryptedDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepDarkBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        // Back Header Returns
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .border(1.dp, Color.DarkGray, CircleShape)
                    .background(DarkSurface, CircleShape)
            ) {
                Icon(Icons.Default.ChevronRight, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "الخزنة المشفرة لصور ومقاطع الخصوصية",
                color = Color.White,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Vault AES guidelines description Card
        GlassCard(
            glowColor = GreenNeon,
            glowRadius = 10.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "تشفير عالي الحماية AES-256 🛡️",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "يتم تعمية وتخزين كل صورة أو ملف تودعه الخزنة بأقوى خوارزميات التشفير العسكري AES-256. لا تظهر الصور في معرض هاتفك المعتاد كلياً.",
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = { showImportDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = GreenNeon),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Add, contentDescription = "Add inside cryptography vault", tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تشفير وإيداع ملف جديد بالخزنة 🔐", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = "الملفات المحفوظة بالخزنة (${vaultItems.size})",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 4.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (vaultItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Lock, contentDescription = "empty", tint = Color.Gray, modifier = Modifier.size(54.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("الخزنة فارغة حالياً.", color = Color.Gray, fontSize = 12.sp)
                }
            }
        } else {
            // LazyVerticalGrid showing encrypted vault elements
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(vaultItems) { item ->
                    VaultItemGridTile(
                        item = item,
                        onDeleteClick = { viewModel.deleteFromVault(item) },
                        onViewClick = {
                            val decrypted = viewModel.decryptAndRetrieveFile(item)
                            if (decrypted != null) {
                                dialogDecryptedContent = String(decrypted)
                                showDecryptedDialog = true
                            }
                        }
                    )
                }
            }
        }
    }

    // Interactive File Import Dialog
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor = DarkSurface,
            title = { Text("تشفير ملف بالخزنة 🔒", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("أدخل اسم الملف ومحتواه التخيلي للمحاكاة والتشفير:", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(bottom = 12.dp))
                    
                    OutlinedTextField(
                        value = importFileName,
                        onValueChange = { importFileName = it },
                        placeholder = { Text("اسم الصورة، مثال: secret_card.png", color = Color.Gray, fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = GreenNeon, unfocusedBorderColor = DarkBorder),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = importFileContent,
                        onValueChange = { importFileContent = it },
                        placeholder = { Text("أدخل تفاصيل حساسة هنا للتشفير والمحاكاة الآمنة...", color = Color.Gray, fontSize = 11.sp) },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = GreenNeon, unfocusedBorderColor = DarkBorder),
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("حدد صنف الملف التلقائي:", color = Color.Gray, fontSize = 11.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { importFileType = "PHOTO" },
                            colors = ButtonDefaults.buttonColors(containerColor = if (importFileType == "PHOTO") GreenNeon else Color.DarkGray),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("صورة 🖼️", color = if (importFileType == "PHOTO") Color.Black else Color.White, fontSize = 10.sp)
                        }
                        Button(
                            onClick = { importFileType = "VIDEO" },
                            colors = ButtonDefaults.buttonColors(containerColor = if (importFileType == "VIDEO") GreenNeon else Color.DarkGray),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("مقطع 🎥", color = if (importFileType == "VIDEO") Color.Black else Color.White, fontSize = 10.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (importFileName.isNotBlank() && importFileContent.isNotBlank()) {
                            viewModel.encryptAndImportFile(
                                fileName = importFileName,
                                content = importFileContent.toByteArray(),
                                fileType = importFileType
                            )
                            showImportDialog = false
                            importFileName = ""
                            importFileContent = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenNeon)
                ) {
                    Text("تشفير وحفظ ✔️", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("إلغاء", color = Color.Gray)
                }
            }
        )
    }

    // Decrypted Content Details Dialog
    if (showDecryptedDialog) {
        AlertDialog(
            onDismissRequest = { showDecryptedDialog = false },
            containerColor = DarkSurface,
            title = { Text("فك تشفير الملف المسترجع 🔓", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("تم فك تعمية تشفير AES-256 بنجاح واسترجاع بنية البايتات للملف الأصلي:", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black, RoundedCornerShape(12.dp))
                            .border(1.dp, GreenNeon.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Text(
                            text = dialogDecryptedContent ?: "خطأ في فك ترميز المحتوى التخيلي.",
                            color = GreenNeon,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showDecryptedDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenNeon)
                ) {
                    Text("موافق", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun VaultItemGridTile(
    item: VaultFile,
    onDeleteClick: () -> Unit,
    onViewClick: () -> Unit
) {
    Surface(
        color = DarkSurface,
        border = BorderStroke(0.5.dp, DarkBorder),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Top Item representation Icon
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (item.fileType == "PHOTO") Icons.Default.InsertPhoto else Icons.Default.Movie,
                    contentDescription = "vault item file type",
                    tint = GreenNeon,
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = item.originalName,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "الحجم: ${item.fileSize} Bytes",
                color = Color.Gray,
                fontSize = 9.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Sub control action triggers
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onViewClick,
                    modifier = Modifier
                        .size(34.dp)
                        .background(GreenNeon.copy(alpha = 0.12f), CircleShape)
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = "retrieve decrypted file", tint = GreenNeon, modifier = Modifier.size(14.dp))
                }

                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier
                        .size(34.dp)
                        .background(RedError.copy(alpha = 0.12f), CircleShape)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "delete encrypted file", tint = RedError, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MainViewModel
import com.example.data.VaultFile
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun VaultScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val vaultItems by viewModel.vaultFiles.collectAsState()
    val isUnlocked by viewModel.isVaultUnlocked.collectAsState()
    val wrongAttempts by viewModel.wrongPasscodeCount.collectAsState()

    // Filter media items from camera trap intruder entries
    val mediaItems = remember(vaultItems) {
        vaultItems.filter { it.fileType != "INTRUDER" }
    }
    val intruderItems = remember(vaultItems) {
        vaultItems.filter { it.fileType == "INTRUDER" }
    }

    var showImportDialog by remember { mutableStateOf(false) }
    var importFileName by remember { mutableStateOf("") }
    var importFileContent by remember { mutableStateOf("") }
    var importFileType by remember { mutableStateOf("PHOTO") } // PHOTO, VIDEO

    var dialogDecryptedContent by remember { mutableStateOf<String?>(null) }
    var showDecryptedDialog by remember { mutableStateOf(false) }

    var selectedIntruder by remember { mutableStateOf<VaultFile?>(null) }

    if (!isUnlocked) {
        VaultPinLockPad(
            wrongAttempts = wrongAttempts,
            onVerify = { pin ->
                val success = viewModel.verifyVaultPasscode(pin)
                if (success) {
                    Toast.makeText(context, "🔓 تم فك حظر الخزنة بنجاح!", Toast.LENGTH_SHORT).show()
                } else {
                    if (wrongAttempts + 1 >= 2) {
                        Toast.makeText(context, "📸 تفعيل فخ الأمان! تم التقاط صورة للمتسلل وحفظها مشفرة بالخلفية!", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "❌ رمز المرور خاطئ! متبقي محاولة واحدة لتفعيل الفخ الكاميرا!", Toast.LENGTH_LONG).show()
                    }
                }
            },
            onBack = onNavigateBack
        )
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DeepDarkBg)
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .border(1.dp, Color.DarkGray, CircleShape)
                        .background(DarkSurface, CircleShape)
                ) {
                    Icon(Icons.Default.ChevronRight, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = "الخزنة المشفرة لصور ومقاطع الخصوصية 🔐",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = { viewModel.lockVault() },
                    modifier = Modifier
                        .border(1.dp, Color.DarkGray, CircleShape)
                        .background(DarkSurface, CircleShape)
                ) {
                    Icon(Icons.Default.Lock, contentDescription = "Lock", tint = RedError)
                }
            }

            // Description info
            GlassCard(
                glowColor = GreenNeon,
                glowRadius = 10.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "أقوى خوارزميات التشفير العسكري AES-256 🛡️",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "يتم تعمية وتفتيت بنية أي ملف أو صورة تودعها الخزنة. لن تظهر هذه الأصول في معرض صور جوالك العام إطلاقاً إلا عبر المصادقة.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { showImportDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenNeon),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Add, contentDescription = "Import new", tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("إيداع وتشفير ملف جديد بالأمان 🔐", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Tab / Header Section for Intruder Captures if any
            if (intruderItems.isNotEmpty()) {
                Text(
                    text = "سجل أفخاخ الكاميرا ومحاولات التجسس المرصودة 🚨",
                    color = RedError,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
                )
                
                // Horizontal list showing intruder alerts
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(84.dp)
                        .padding(bottom = 12.dp)
                ) {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(110.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(intruderItems) { item ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(RedError.copy(alpha = 0.15f))
                                    .border(1.dp, RedError.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                    .clickable { selectedIntruder = item }
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Security, contentDescription = null, tint = RedError, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "متسلل #${item.originalName.takeLast(4)}",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Text(
                text = "الملفات المشفرة المخزنة بالخزنة (${mediaItems.size})",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (mediaItems.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Lock, contentDescription = "empty", tint = Color.Gray, modifier = Modifier.size(54.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("الخزنة لا تملك ملفات مشفرة حالياً.", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(mediaItems) { item ->
                        VaultItemGridTile(
                            item = item,
                            onDeleteClick = { viewModel.deleteFromVault(item) },
                            onViewClick = {
                                val decrypted = viewModel.decryptAndRetrieveFile(item)
                                if (decrypted != null) {
                                    dialogDecryptedContent = String(decrypted)
                                    showDecryptedDialog = true
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // Modal dialogue for Intruder captures detail
    if (selectedIntruder != null) {
        val intruder = selectedIntruder!!
        AlertDialog(
            onDismissRequest = { selectedIntruder = null },
            containerColor = DarkSurface,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Report, contentDescription = null, tint = RedError)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("المتسلل المرصود بالكامل 🚨", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text(
                        text = "تفاصيل عملية الاختراق لكشف أسرارك ومحتوياتك:",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black, RoundedCornerShape(12.dp))
                            .border(1.dp, RedError.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Text(text = "🛡️ تصنيف الكاميرا: كاميرا سيلفي وقائية", color = RedError, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = "⏱️ التاريخ: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(intruder.addedTimestamp))}", color = Color.White, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "❌ السبب: إدخال رمز قفل الخزنة بصورة خاطئة لمرتين متتاليتين.", color = Color.LightGray, fontSize = 11.sp, lineHeight = 16.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "📂 الملف المخرن: ${intruder.originalName}.enc (مشفّر AES بنظام الكبسولة لقطع العبث)", color = Color.Gray, fontSize = 10.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { 
                        viewModel.deleteFromVault(intruder)
                        selectedIntruder = null 
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedError)
                ) {
                    Text("حذف السجل نهائياً", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedIntruder = null }) {
                    Text("إغلاق", color = Color.Gray)
                }
            }
        )
    }

    // Import Dialog
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor = DarkSurface,
            title = { Text("تشفير ملف بالخزنة 🔒", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("أدخل اسم الملف ومحتواه التخيلي للمحاكاة والتشفير:", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(bottom = 12.dp))
                    
                    OutlinedTextField(
                        value = importFileName,
                        onValueChange = { importFileName = it },
                        placeholder = { Text("اسم الصورة، مثال: secret_card.png", color = Color.Gray, fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = GreenNeon, unfocusedBorderColor = DarkBorder),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = importFileContent,
                        onValueChange = { importFileContent = it },
                        placeholder = { Text("أدخل تفاصيل حساسة هنا للتشفير والمحاكاة الآمنة...", color = Color.Gray, fontSize = 11.sp) },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = GreenNeon, unfocusedBorderColor = DarkBorder),
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("حدد صنف الملف التلقائي:", color = Color.Gray, fontSize = 11.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { importFileType = "PHOTO" },
                            colors = ButtonDefaults.buttonColors(containerColor = if (importFileType == "PHOTO") GreenNeon else Color.DarkGray),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("صورة 🖼️", color = if (importFileType == "PHOTO") Color.Black else Color.White, fontSize = 10.sp)
                        }
                        Button(
                            onClick = { importFileType = "VIDEO" },
                            colors = ButtonDefaults.buttonColors(containerColor = if (importFileType == "VIDEO") GreenNeon else Color.DarkGray),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("مقطع 🎥", color = if (importFileType == "VIDEO") Color.Black else Color.White, fontSize = 10.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (importFileName.isNotBlank() && importFileContent.isNotBlank()) {
                            viewModel.encryptAndImportFile(
                                fileName = importFileName,
                                content = importFileContent.toByteArray(),
                                fileType = importFileType
                            )
                            showImportDialog = false
                            importFileName = ""
                            importFileContent = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenNeon)
                ) {
                    Text("تشفير وحفظ ✔️", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("إلغاء", color = Color.Gray)
                }
            }
        )
    }

    // Decrypted content view dialog
    if (showDecryptedDialog) {
        AlertDialog(
            onDismissRequest = { showDecryptedDialog = false },
            containerColor = DarkSurface,
            title = { Text("فك تشفير الملف المسترجع 🔓", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("تم فك تعمية تشفير AES-256 بنجاح واسترجاع بنية البايتات للملف الأصلي:", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black, RoundedCornerShape(12.dp))
                            .border(1.dp, GreenNeon.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Text(
                            text = dialogDecryptedContent ?: "خطأ في فك ترميز المحتوى التخيلي.",
                            color = GreenNeon,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showDecryptedDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenNeon)
                ) {
                    Text("موافق", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
fun VaultPinLockPad(
    wrongAttempts: Int,
    onVerify: (String) -> Unit,
    onBack: () -> Unit
) {
    var pinText by remember { mutableStateOf("") }
    val maxLen = 4

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepDarkBg)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = null,
            tint = GreenNeon,
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "الخزنة السيبرانية مغلقة المشفرة 🛡️",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )
        Text(
            text = "أدخل الرمز السري للعبور للكبسولة (الرمز الافتراضي: 1337)\nالمحاولات الخاطئة المتكررة تفعل الكاميرا الأمامية فوراً التقاط فخ المتسلل!",
            color = Color.Gray,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            lineHeight = 16.sp,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        if (wrongAttempts > 0) {
            Text(
                text = "المحاولات الخاطئة: $wrongAttempts / 2 ⚠️",
                color = RedError,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        // Indicator dots
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(vertical = 16.dp)
        ) {
            for (i in 1..maxLen) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .border(1.5.dp, if (pinText.length >= i) GreenNeon else Color.Gray, CircleShape)
                        .background(if (pinText.length >= i) GreenNeon else Color.Transparent, CircleShape)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Virtual Num Keypad 3x4
        val keys = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("❌", "0", "✔️")
        )

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            keys.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    row.forEach { key ->
                        Button(
                            onClick = {
                                when (key) {
                                    "❌" -> {
                                        if (pinText.isNotEmpty()) pinText = pinText.dropLast(1)
                                    }
                                    "✔️" -> {
                                        if (pinText.length == maxLen) {
                                            onVerify(pinText)
                                            pinText = ""
                                        }
                                    }
                                    else -> {
                                        if (pinText.length < maxLen) {
                                            pinText += key
                                            if (pinText.length == maxLen) {
                                                onVerify(pinText)
                                                pinText = ""
                                            }
                                        }
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkSurface),
                            shape = CircleShape,
                            border = BorderStroke(1.dp, Color.DarkGray),
                            modifier = Modifier.size(68.dp)
                        ) {
                            Text(text = key, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))

        TextButton(onClick = onBack) {
            Text("العودة للرئيسية", color = GreenNeon, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun VaultItemGridTile(
    item: VaultFile,
    onDeleteClick: () -> Unit,
    onViewClick: () -> Unit
) {
    GlassCard(
        glowColor = if (item.fileType == "PHOTO") GreenNeon else PurpleNeon,
        glowRadius = 6.dp,
        modifier = Modifier
            .fillMaxWidth()
            .height(115.dp)
            .clickable { onViewClick() }
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (item.fileType == "PHOTO") Icons.Default.Photo else Icons.Default.Videocam,
                    contentDescription = null,
                    tint = if (item.fileType == "PHOTO") GreenNeon else PurpleNeon,
                    modifier = Modifier.size(20.dp)
                )
                
                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = RedError.copy(alpha = 0.8f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Column {
                Text(
                    text = item.originalName,
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "حجم: ${String.format("%.1f", item.fileSize / 1024.0)} KB",
                    color = Color.Gray,
                    fontSize = 9.sp
                )
            }
        }
    }
}

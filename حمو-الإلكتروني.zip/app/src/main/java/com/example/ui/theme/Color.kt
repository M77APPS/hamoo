package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyanNeon = Color(0xFF00E5FF)
val PrimaryContainer = Color(0xFF003544)
val OnPrimary = Color(0xFF000000)

val PurpleNeon = Color(0xFFD500F9)
val SecondaryContainer = Color(0xFF3700B3)

val GreenNeon = Color(0xFF39FF14)

val DeepDarkBg = Color(0xFF0A0A0A)
val DarkSurface = Color(0xFF1C1C1E)
val DarkBorder = Color(0xFF2C2C2E)

val RedError = Color(0xFFFF0266)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFE0E0E0)

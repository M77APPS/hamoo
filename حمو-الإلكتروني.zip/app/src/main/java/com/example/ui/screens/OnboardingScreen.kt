package com.example.ui.screens

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassCard
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.DeepDarkBg
import com.example.ui.theme.GreenNeon
import com.example.ui.theme.PurpleNeon

import androidx.compose.ui.platform.LocalContext

@Composable
fun OnboardingScreen(
    onFinished: () -> Unit
) {
    val context = LocalContext.current
    var currentPage by remember { mutableStateOf(0) }
    var isAgreed by remember { mutableStateOf(false) }
    
    val pages = listOf(
        OnboardingPageData(
            title = "الكشف الخارق",
            desc = "يفحص حمو عمليات هاتفك بالكامل ويكتشف البرمجيات الخبيثة والتطبيقات متنكرة الهوية لضمان حماية لا تخترق.",
            iconColor = CyanNeon
        ),
        OnboardingPageData(
            title = "حماية بنقرة واحدة",
            desc = "تفعيل جدار الحماية والـ VPN الذكي لتشفير اتصالاتك كلياً وتصفح الإنترنت بهوية آمنة تمنع التعقب والتجسس السحابي.",
            iconColor = PurpleNeon
        ),
        OnboardingPageData(
            title = "خصوصية بلا حدود",
            desc = "امنع التطبيقات من اختراق كاميرتك ومايكروفونك سراً، واحفظ صورك ومستنداتك بخزنة معماة بـ AES-256 لا يعلمها أحد سواك.",
            iconColor = GreenNeon
        ),
        OnboardingPageData(
            title = "اتفاقية الاستخدام والمسؤولية ⚖️",
            desc = "يتعهد مستخدم التطبيق بالامتثال للأغراض الدفاعية والأخلاقية الشخصية فقط. يُحظر كلياً استعمال التطبيق في تتبع أو تجسس أو اختراق الآخرين مسبقاً، والمطور بريء من أي إساءة.",
            iconColor = Color(0xFFFF3333)
        )
    )

    // Permission launcher to handle post notify and standard checks
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Proceed on permissions feedback
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepDarkBg),
        contentAlignment = Alignment.Center
    ) {
        // Holographic Background grid
        Canvas(modifier = Modifier.fillMaxSize()) {
            val step = 60f
            for (x in 0..size.width.toInt() step step.toInt()) {
                drawLine(
                    color = CyanNeon.copy(alpha = 0.03f),
                    start = Offset(x.toFloat(), 0f),
                    end = Offset(x.toFloat(), size.height),
                    strokeWidth = 1f
                )
            }
            for (y in 0..size.height.toInt() step step.toInt()) {
                drawLine(
                    color = CyanNeon.copy(alpha = 0.03f),
                    start = Offset(0f, y.toFloat()),
                    end = Offset(size.width, y.toFloat()),
                    strokeWidth = 1f
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Top
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "حمـو الإلكترونـي 🛡️",
                    color = CyanNeon,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                
                Text(
                    text = "تخطي",
                    color = Color.Gray,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable { onFinished() }
                )
            }

            // Animated Slide Content
            AnimatedContent(
                targetState = currentPage,
                transitionSpec = {
                    fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                },
                label = "PageNavAnim"
            ) { pageIndex ->
                val page = pages[pageIndex]
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Custom interactive canvas illustrating cyberpunk shield orb
                    Box(
                        modifier = Modifier
                            .size(220.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Radar/scanner grid
                            drawCircle(
                                color = page.iconColor.copy(alpha = 0.15f),
                                radius = size.minDimension / 2.3f
                            )
                            drawCircle(
                                color = page.iconColor.copy(alpha = 0.3f),
                                radius = size.minDimension / 3.5f,
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
                            )
                            drawCircle(
                                color = page.iconColor,
                                radius = size.minDimension / 6f,
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 5f)
                            )
                        }
                        
                        // Large Shield Symbol Glow
                        Text(
                            text = if (pageIndex == 0) "👁️" else if (pageIndex == 1) "⚡" else if (pageIndex == 2) "🔒" else "⚖️",
                            fontSize = 62.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(30.dp))

                    Text(
                        text = page.title,
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = page.desc,
                        color = Color.LightGray,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        lineHeight = 24.sp,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )

                    if (pageIndex == pages.size - 1) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isAgreed = !isAgreed }
                                .padding(horizontal = 12.dp)
                        ) {
                            Checkbox(
                                checked = isAgreed,
                                onCheckedChange = { isAgreed = it },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = GreenNeon,
                                    uncheckedColor = Color.Gray
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "أوافق على بنود الاستخدام الدفاعي والأخلاقي للمنظومة 📜",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Footer Section
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Page Indicator Dot bars
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    pages.forEachIndexed { idx, _ ->
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 4.dp)
                                .height(6.dp)
                                .width(if (idx == currentPage) 24.dp else 8.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (idx == currentPage) CyanNeon else Color.DarkGray)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(40.dp))

                // Control Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (currentPage > 0) {
                        IconButton(
                            onClick = { currentPage-- },
                            modifier = Modifier
                                .border(1.dp, Color.Gray, CircleShape)
                                .size(50.dp)
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    } else {
                        Spacer(modifier = Modifier.size(50.dp))
                    }

                    // Huge Glowing "ابدأ الآن" or "التالي" Action Button
                    Button(
                        onClick = {
                            if (currentPage < pages.size - 1) {
                                currentPage++
                            } else {
                                if (!isAgreed) {
                                    Toast.makeText(context, "الرجاء الموافقة على البنود الشرعية والقانونية للمتابعة 📜", Toast.LENGTH_LONG).show()
                                    return@Button
                                }
                                // Request standard notifications and camera permission for real-time monitoring alerts
                                val perms = mutableListOf<String>()
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    perms.add(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                if (perms.isNotEmpty()) {
                                    permissionLauncher.launch(perms.toTypedArray())
                                }
                                onFinished()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (currentPage == pages.size - 1) {
                                if (isAgreed) GreenNeon else Color.DarkGray
                            } else {
                                CyanNeon
                            }
                        ),
                        shape = RoundedCornerShape(25.dp),
                        modifier = Modifier
                            .height(50.dp)
                            .shadow(
                                elevation = 16.dp,
                                shape = RoundedCornerShape(25.dp),
                                ambientColor = if (currentPage == pages.size - 1) {
                                    if (isAgreed) GreenNeon else Color.Gray
                                } else {
                                    CyanNeon
                                },
                                spotColor = if (currentPage == pages.size - 1) {
                                    if (isAgreed) GreenNeon else Color.Gray
                                } else {
                                    CyanNeon
                                }
                            )
                            .weight(1f)
                            .padding(horizontal = 16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = if (currentPage == pages.size - 1) "انطلق الآن 🚀" else "التالـي",
                                color = if (currentPage == pages.size - 1 && !isAgreed) Color.LightGray else Color.Black,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = if (currentPage == pages.size - 1) Icons.Default.Done else Icons.Default.ArrowForward,
                                contentDescription = "Next",
                                tint = if (currentPage == pages.size - 1 && !isAgreed) Color.LightGray else Color.Black
                            )
                        }
                    }
                }
            }
        }
    }
}

data class OnboardingPageData(
    val title: String,
    val desc: String,
    val iconColor: Color
)

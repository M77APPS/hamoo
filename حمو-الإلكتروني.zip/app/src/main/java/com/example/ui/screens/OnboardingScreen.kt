package com.example.ui.screens

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassCard

@Composable
fun OnboardingScreen(
    onFinished: () -> Unit
) {
    val context = LocalContext.current
    var isAgreed by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    val pureBlack = Color(0xFF000000)
    val neonGreen = Color(0xFF00FF66)
    val dimGray = Color(0xFF888888)

    // Permission launcher to handle post notify and standard checks
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        // Proceed on permissions feedback
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(pureBlack),
        contentAlignment = Alignment.Center
    ) {
        // Holographic Cyberpunk Background grid with neon green lines
        Canvas(modifier = Modifier.fillMaxSize()) {
            val step = 70f
            for (x in 0..size.width.toInt() step step.toInt()) {
                drawLine(
                    color = neonGreen.copy(alpha = 0.04f),
                    start = Offset(x.toFloat(), 0f),
                    end = Offset(x.toFloat(), size.height),
                    strokeWidth = 1f
                )
            }
            for (y in 0..size.height.toInt() step step.toInt()) {
                drawLine(
                    color = neonGreen.copy(alpha = 0.04f),
                    start = Offset(0f, y.toFloat()),
                    end = Offset(size.width, y.toFloat()),
                    strokeWidth = 1f
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Top
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "منظومــة PrivacyGuard الدفاعيــة 🛡️",
                    color = neonGreen,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }

            // Legal Contract compliance document box
            GlassCard(
                glowColor = neonGreen,
                glowRadius = 14.dp,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = "وثيقة الامتثال الأمني وحظر تسريب البيانات لقنوات حمو الإلكتروني",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                    )

                    Divider(color = neonGreen.copy(alpha = 0.3f), modifier = Modifier.padding(bottom = 12.dp))

                    Text(
                        text = "يرتكز هذا التطبيق الأمني على بروتوكول التدقيق المحلي الصارم لفحص الحزم والعمليات النشطة داخل نواة أندرويد لحماية خصوصيتك وصيانتها من الأطراف المترصدة بدون الحاجة لخوادم وسيطة سحابية قد تتسب بامتصاص بياناتك.\n\n" +
                               "١. الفحص محلي بالكامل:\n" +
                               "تقوم أدوات التحليل بفحص وتفكيك الأمان للبرمجيات المثبتة عبر PackageManager للوقوف على الصلاحيات المقاطعة وقنوات التوجيه USSD والشهادات المزروعة (CA Root Certificates) دون أن نرسل أي بيانات خارج جهازك الإقليمي.\n\n" +
                               "٢. سلامة الاتصال ونفق الـ VPN المحلي:\n" +
                               "ينشئ جدار الحماية نفق Loopback محلياً فقط من أجل مراقبة وعزل الحزم الصادرة من التطبيقات الخبيثة وفك محاولات رجل المنتصف سرياً، ويحق للمستخدم التحكم بكافة خيارات بروكسي SOCKS5.\n\n" +
                               "٣. مسؤولية الاستخدام:\n" +
                               "يقر المستخدم باستخدامه للمنظومة في الأغراض الوقائية الدفاعية الشخصية والتعليمية فقط. يُمنع منعاً باتاً استغلال أي ميزة مدمجة للإضرار بالآخرين أو بالتنصت غير الأخلاقي، ويخلي المطور (محمد حسام) مسؤوليته الكاملة عن أي استخدام خارج هذه المعايير المعرفية.\n\n" +
                               "هندسة وتطوير تكنولوجي حر: محمد حسام (حمو الإلكتروني) - خبير الأنظمة الدفاعية ومستشار المنصات المستقلة للأمن السيبراني © 2026.",
                        color = Color.LightGray,
                        fontSize = 13.sp,
                        lineHeight = 22.sp,
                        textAlign = TextAlign.Justify,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Consent check block
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isAgreed = !isAgreed }
                    .padding(vertical = 10.dp)
            ) {
                Checkbox(
                    checked = isAgreed,
                    onCheckedChange = { isAgreed = it },
                    colors = CheckboxDefaults.colors(
                        checkedColor = neonGreen,
                        uncheckedColor = dimGray,
                        checkmarkColor = Color.Black
                    )
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "أوافق على وثيقة الامتثال والبنود الأمنية المنصوص عليها 📜",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Massive Neon Trigger Action Button
            Button(
                onClick = {
                    if (!isAgreed) {
                        Toast.makeText(context, "الرجاء تأكيد الامتثال والموافقة على الوثيقة للمتابعة 📜", Toast.LENGTH_LONG).show()
                        return@Button
                    }
                    val perms = mutableListOf<String>()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        perms.add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    perms.add(Manifest.permission.READ_PHONE_STATE)
                    perms.add(Manifest.permission.CAMERA)

                    if (perms.isNotEmpty()) {
                        permissionLauncher.launch(perms.toTypedArray())
                    }
                    onFinished()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isAgreed) neonGreen else Color.DarkGray
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .shadow(
                        elevation = if (isAgreed) 16.dp else 0.dp,
                        shape = RoundedCornerShape(20.dp),
                        ambientColor = neonGreen,
                        spotColor = neonGreen
                    )
            ) {
                Text(
                    text = "تفعيل المنظومة الدفاعية والموافقة على بروتوكول الفحص",
                    color = if (isAgreed) Color.Black else dimGray,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

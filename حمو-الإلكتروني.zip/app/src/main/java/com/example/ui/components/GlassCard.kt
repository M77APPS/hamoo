package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    glowColor: Color = CyanNeon,
    glowRadius: Dp = 10.dp,
    onClick: (() -> Unit)? = null,
    borderStroke: BorderStroke? = BorderStroke(1.dp, Brush.radialGradient(listOf(CyanNeon.copy(alpha = 0.4f), DarkBorder.copy(alpha = 0.1f)))),
    content: @Composable ColumnScope.() -> Unit
) {
    var baseModifier = modifier
        .shadow(
            elevation = glowRadius,
            shape = RoundedCornerShape(24.dp),
            clip = false,
            ambientColor = glowColor,
            spotColor = glowColor
        )
        .clip(RoundedCornerShape(24.dp))
        .background(DarkSurface.copy(alpha = 0.75f))

    if (borderStroke != null) {
        baseModifier = baseModifier.border(borderStroke, RoundedCornerShape(24.dp))
    }

    if (onClick != null) {
        baseModifier = baseModifier.clickable(onClick = onClick)
    }

    Column(
        modifier = baseModifier.padding(16.dp),
        content = content
    )
}

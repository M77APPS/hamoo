package com.example.ui.screens

import android.app.Activity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun ScannerScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val scanState by viewModel.scanState.collectAsState()
    val progress by viewModel.scanProgress.collectAsState()
    val currentPackage by viewModel.scannedPackage.collectAsState()
    val foundThreats by viewModel.foundThreats.collectAsState()

    // Preload interstitial ad on launch
    LaunchedEffect(Unit) {
        com.example.ui.components.AdmobHelper.loadInterstitial(context)
    }

    // Trigger interstitial ad once scan is complete
    LaunchedEffect(scanState) {
        if (scanState == "FINISHED_CLEAN" || scanState == "FINISHED_THREATS") {
            activity?.let { act ->
                com.example.ui.components.AdmobHelper.showInterstitial(act) {
                    // Ad was completed/dismissed or failed to display. Resume screen status.
                }
            }
        }
    }

    // Breathing pulse during active scanning
    val infiniteTransition = rememberInfiniteTransition(label = "ScannerBreath")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.93f,
        targetValue = 1.07f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ),
        label = "OrbScale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepDarkBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Back Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onNavigateBack,
                modifier = Modifier
                    .border(1.dp, Color.DarkGray, CircleShape)
                    .background(DarkSurface, CircleShape)
            ) {
                Icon(Icons.Default.ChevronRight, contentDescription = "Back to dashboard", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "الفحص السيبراني والعمليات",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Scanner Core Module Widget
            item {
                ScannerCoreWidget(
                    scanState = scanState,
                    progress = progress,
                    pulseScale = pulseScale,
                    onStartScan = { isDeep ->
                        if (isDeep) {
                            activity?.let { act ->
                                com.example.ui.components.AdmobHelper.showRewardedAd(
                                    activity = act,
                                    onEarned = { viewModel.startCyberScan(isDeep = true) },
                                    onDismiss = {}
                                )
                            }
                        } else {
                            viewModel.startCyberScan(isDeep = false)
                        }
                    }
                )
            }

            // Real-time logging console
            if (scanState == "SCANNING") {
                item {
                    ScanningConsoleWidget(packagePath = currentPackage, progress = progress)
                }
            }

            // Scan complete outcomes
            if (scanState == "FINISHED_CLEAN") {
                item {
                    CleanSuccessWidget(onRestartScan = { viewModel.startCyberScan() })
                }
            }

            if (scanState == "FINISHED_THREATS") {
                item {
                    ThreatAlertWidget(
                        threatsList = foundThreats,
                        onCleanAll = { viewModel.cleanAllThreats() }
                    )
                }
            }
        }
    }
}

@Composable
fun ScannerCoreWidget(
    scanState: String,
    progress: Float,
    pulseScale: Float,
    onStartScan: (isDeep: Boolean) -> Unit
) {
    val orbColor = when (scanState) {
        "SCANNING" -> CyanNeon
        "FINISHED_CLEAN" -> GreenNeon
        "FINISHED_THREATS" -> RedError
        else -> CyanNeon
    }

    GlassCard(
        glowColor = orbColor,
        glowRadius = 14.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "ماسح الهواتف الذكي الخارق",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "فحص متقاطع لتوقيع الفيروسات وسلوك التطبيقات المريب",
                color = TextSecondary,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // Massive Central Orbit Board
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .scale(if (scanState == "SCANNING") pulseScale else 1.0f),
                contentAlignment = Alignment.Center
            ) {
                // Background Glow Wave
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(
                        color = orbColor.copy(alpha = 0.05f),
                        radius = size.minDimension / 2.1f
                    )
                }

                // Rotating progress arc path
                CircularProgressIndicator(
                    progress = if (scanState == "SCANNING") progress else 1.0f,
                    strokeWidth = 10.dp,
                    color = orbColor,
                    trackColor = Color.DarkGray.copy(alpha = 0.3f),
                    strokeCap = StrokeCap.Round,
                    modifier = Modifier.fillMaxSize()
                )

                // Central interactive pulse Shield
                Button(
                    onClick = { if (scanState != "SCANNING") onStartScan(false) },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurface),
                    shape = CircleShape,
                    border = BorderStroke(2.dp, Brush.linearGradient(listOf(orbColor, Color.Transparent))),
                    modifier = Modifier
                        .size(140.dp)
                        .shadow(16.dp, CircleShape, spotColor = orbColor, ambientColor = orbColor)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Shield",
                            tint = orbColor,
                            modifier = Modifier.size(46.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = when (scanState) {
                                "SCANNING" -> "${(progress * 100).toInt()}%"
                                "FINISHED_CLEAN" -> "آمن مئة٪"
                                "FINISHED_THREATS" -> "تهديد مكشوف!"
                                else -> "افحص الآن"
                            },
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Choose Scan Type buttons below the central shield
            if (scanState != "SCANNING") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { onStartScan(false) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyanNeon),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "فحص سريع ⚡",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }

                    Button(
                        onClick = { onStartScan(true) },
                        colors = ButtonDefaults.buttonColors(containerColor = PurpleNeon),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "فحص عميق 💎 (فيديو)",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun ScanningConsoleWidget(packagePath: String, progress: Float) {
    Surface(
        color = Color.Black,
        border = BorderStroke(1.dp, CyanNeon.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "حالة التشخيص السيبراني...", color = CyanNeon, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(text = "جارِ تفجير الأورام الخبيثة...", color = Color.Gray, fontSize = 10.sp)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "رصد وتحليل الاستدلال الهيكلي:",
                color = Color.DarkGray,
                fontSize = 10.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            // Live Package name
            Text(
                text = packagePath,
                color = Color.LightGray,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
fun CleanSuccessWidget(onRestartScan: () -> Unit) {
    GlassCard(
        glowColor = GreenNeon,
        glowRadius = 16.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(GreenNeon.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("✔️", fontSize = 24.sp)
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(text = "الهاتف آمن ١٠٠٪ بنجاح", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(
                text = "لم يتم الكشف عن برمجيات تجسس الكود، جدار الاستماع كتم المحاولات، وجهازك الآن محصن بالكامل تحت نظام حمو.",
                color = TextSecondary,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
            )

            Button(
                onClick = onRestartScan,
                colors = ButtonDefaults.buttonColors(containerColor = GreenNeon),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.height(40.dp)
            ) {
                Text(text = "تحديث الفحص السريع 🔄", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun ThreatAlertWidget(threatsList: List<String>, onCleanAll: () -> Unit) {
    GlassCard(
        glowColor = RedError,
        glowRadius = 18.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "برامج تجسس مكتشفة (العدد: ${threatsList.size}) ⚠️",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                
                Button(
                    onClick = onCleanAll,
                    colors = ButtonDefaults.buttonColors(containerColor = RedError),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text(text = "إبادة الكل", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Threats listings
            threatsList.forEach { threat ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RedError.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                        .border(1.dp, RedError.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.BugReport, contentDescription = "malware", tint = RedError, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(text = threat, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

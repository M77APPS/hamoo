package com.example.ui.components

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.appopen.AppOpenAd
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface

object AdmobHelper {
    private const val TAG = "AdmobHelper"

    // Real AdMob IDs under Mohamed Hossam's account
    const val APP_ID = "ca-app-pub-1797121655529913~1806796443"
    const val BANNER_ID = "ca-app-pub-1797121655529913/9352594060"
    const val REWARDED_ID = "ca-app-pub-1797121655529913/4100267381"
    const val APP_OPEN_ID = "ca-app-pub-1797121655529913/7544688375"

    // Test fallbacks just in case of environment network restrictions
    const val TEST_BANNER = "ca-app-pub-3940256099942544/6300978111"
    const val TEST_INTERSTITIAL = "ca-app-pub-3940256099942544/1033173712"
    const val TEST_REWARDED = "ca-app-pub-3940256099942544/5224354917"
    const val TEST_APP_OPEN = "ca-app-pub-3940256099942544/9257395921"

    private var interstitialAd: InterstitialAd? = null
    private var isInterstitialLoading = false

    private var rewardedAd: RewardedAd? = null
    private var isRewardedLoading = false

    private var appOpenAd: AppOpenAd? = null
    private var isAppOpenLoading = false

    /**
     * Preloads the Interstitial Ad
     */
    fun loadInterstitial(context: Context) {
        if (interstitialAd != null || isInterstitialLoading) return
        isInterstitialLoading = true
        val adRequest = AdRequest.Builder().build()
        
        // Use TEST_INTERSTITIAL or APP_OPEN_ID as an interstitial fallback if direct unit is absent
        InterstitialAd.load(
            context,
            TEST_INTERSTITIAL,
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                    Log.d(TAG, "Interstitial loaded successfully")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                    isInterstitialLoading = false
                    Log.e(TAG, "Interstitial failed: ${error.message}")
                }
            }
        )
    }

    /**
     * Shows Interstitial Ad with safe callback
     */
    fun showInterstitial(activity: Activity, onDismiss: () -> Unit) {
        val ad = interstitialAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    loadInterstitial(activity)
                    onDismiss()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialAd = null
                    onDismiss()
                }
            }
            ad.show(activity)
        } else {
            Log.d(TAG, "Interstitial not preloaded, bypassing")
            onDismiss()
        }
    }

    /**
     * Preloads the Rewarded Ad (MOCAFAA)
     */
    fun loadRewardedAd(context: Context) {
        if (rewardedAd != null || isRewardedLoading) return
        isRewardedLoading = true
        val adRequest = AdRequest.Builder().build()

        RewardedAd.load(
            context,
            REWARDED_ID,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isRewardedLoading = false
                    Log.d(TAG, "Rewarded ad (MOCAFAA) loaded.")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.e(TAG, "Rewarded failed loading, trying test fallback: ${error.message}")
                    // Retry once with test unit to guarantee user access in sandbox
                    RewardedAd.load(
                        context,
                        TEST_REWARDED,
                        adRequest,
                        object : RewardedAdLoadCallback() {
                            override fun onAdLoaded(ad: RewardedAd) {
                                rewardedAd = ad
                                isRewardedLoading = false
                                Log.d(TAG, "Rewarded standard test ad loaded.")
                            }
                            override fun onAdFailedToLoad(fallbackError: LoadAdError) {
                                rewardedAd = null
                                isRewardedLoading = false
                                Log.e(TAG, "All rewarded ad loading attempts failed.")
                            }
                        }
                    )
                }
            }
        )
    }

    /**
     * Shows the Rewarded Ad before running critical actions
     */
    fun showRewardedAd(activity: Activity, onEarned: () -> Unit, onDismiss: () -> Unit) {
        val ad = rewardedAd
        if (ad != null) {
            var rewarded = false
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewardedAd(activity)
                    if (rewarded) {
                        onEarned()
                    } else {
                        onDismiss()
                    }
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    rewardedAd = null
                    Log.e(TAG, "Rewarded failed to show: ${error.message}")
                    // Grant access anyway if showing fails, to build trust
                    onEarned()
                }
            }
            ad.show(activity, OnUserEarnedRewardListener {
                rewarded = true
                Log.d(TAG, "User watched video completely. Access granted!")
            })
        } else {
            Log.w(TAG, "Rewarded ad was not ready. Accessing fallback process.")
            // Try loading for next time and let them inside
            loadRewardedAd(activity)
            onEarned() // Sandbox grace allowance
        }
    }

    /**
     * Preloads App Open Ad
     */
    fun loadAppOpenAd(context: Context) {
        if (appOpenAd != null || isAppOpenLoading) return
        isAppOpenLoading = true
        val request = AdRequest.Builder().build()
        AppOpenAd.load(
            context,
            APP_OPEN_ID,
            request,
            object : AppOpenAd.AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenAd = ad
                    isAppOpenLoading = false
                    Log.d(TAG, "App Open Ad loaded.")
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.e(TAG, "App Open failed. Retrying with test token.")
                    AppOpenAd.load(
                        context,
                        TEST_APP_OPEN,
                        request,
                        object : AppOpenAd.AppOpenAdLoadCallback() {
                            override fun onAdLoaded(ad: AppOpenAd) {
                                appOpenAd = ad
                                isAppOpenLoading = false
                            }
                            override fun onAdFailedToLoad(testError: LoadAdError) {
                                appOpenAd = null
                                isAppOpenLoading = false
                            }
                        }
                    )
                }
            }
        )
    }

    /**
     * Shows App Open Ad
     */
    fun showAppOpenAd(activity: Activity, onDismiss: () -> Unit = {}) {
        val ad = appOpenAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    appOpenAd = null
                    loadAppOpenAd(activity)
                    onDismiss()
                }

                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    appOpenAd = null
                    loadAppOpenAd(activity)
                    onDismiss()
                }
            }
            ad.show(activity)
        } else {
            loadAppOpenAd(activity)
            onDismiss()
        }
    }
}

/**
 * Modern Jetpack Compose wrapper for Google AdMob Banner Ads
 */
@Composable
fun BannerAdView(modifier: Modifier = Modifier) {
    var adFailedToLoad by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .background(DarkSurface, RoundedCornerShape(12.dp))
            .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (adFailedToLoad) {
            Text(
                text = "🛡️ درع أنشطة حمو - رعاية أمنية معتمدة",
                color = Color.LightGray.copy(alpha = 0.6f),
                fontSize = 11.sp
            )
        } else {
            AndroidView(
                factory = { context ->
                    AdView(context).apply {
                        setAdSize(AdSize.BANNER)
                        adUnitId = AdmobHelper.BANNER_ID
                        adListener = object : AdListener() {
                            override fun onAdFailedToLoad(error: LoadAdError) {
                                super.onAdFailedToLoad(error)
                                Log.e("AdmobBanner", "Failed to load banner: ${error.message}. Retrying with test unit.")
                                // Fallback to test unit inside the view
                                post {
                                    try {
                                        adUnitId = AdmobHelper.TEST_BANNER
                                        loadAd(AdRequest.Builder().build())
                                    } catch (e: Exception) {
                                        adFailedToLoad = true
                                    }
                                }
                            }
                        }
                        loadAd(AdRequest.Builder().build())
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

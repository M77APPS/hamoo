package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

@Composable
fun MainDashboard(
    viewModel: MainViewModel,
    onNavigateToScanner: () -> Unit,
    onNavigateToAppLock: () -> Unit,
    onNavigateToVPN: () -> Unit,
    onNavigateToVault: () -> Unit,
    onNavigateToDarkWeb: () -> Unit,
    onNavigateToPermissions: () -> Unit
) {
    val score by viewModel.securityScore.collectAsState()
    val isVpnActive by viewModel.isVpnActive.collectAsState()
    val isMonitorActive by viewModel.isMonitorActive.collectAsState()
    val alertsFeed by viewModel.accessLogs.collectAsState()
    val scanRecordList by viewModel.scanRecords.collectAsState()

    // Breathing pulse for warning alerts
    val infiniteTransition = rememberInfiniteTransition(label = "WarningFlash")
    val warningAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutQuad),
            repeatMode = RepeatMode.Reverse
        ),
        label = "AlphaFlash"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepDarkBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(top = 16.dp, start = 16.dp, end = 16.dp)
    ) {
        // --- Top Branding Bar ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .border(1.dp, CyanNeon, CircleShape)
                        .background(CyanNeon.copy(alpha = 0.1f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("ح", color = CyanNeon, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("حمو الإلكتروني", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("المساعد الأمني الموثوق", color = Color.Gray, fontSize = 11.sp)
                }
            }

            // Crown Premium upgrade trigger
            IconButton(
                onClick = { /* Upgrade Premium action */ },
                modifier = Modifier
                    .border(BorderStroke(1.dp, Brush.radialGradient(listOf(PurpleNeon, Color.Transparent))), CircleShape)
                    .background(PurpleNeon.copy(alpha = 0.15f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "Premium Core Upgrade",
                    tint = PurpleNeon
                )
            }
        }

        // --- Live Alerts Feed list and controls ---
        ScrollableDashboardContent(
            score = score,
            isVpnActive = isVpnActive,
            isMonitorActive = isMonitorActive,
            alertsFeed = alertsFeed,
            warningAlpha = warningAlpha,
            onNavigateToScanner = onNavigateToScanner,
            onNavigateToAppLock = onNavigateToAppLock,
            onNavigateToVPN = onNavigateToVPN,
            onNavigateToVault = onNavigateToVault,
            onNavigateToDarkWeb = onNavigateToDarkWeb,
            onNavigateToPermissions = onNavigateToPermissions,
            viewModel = viewModel
        )
    }
}

@Composable
fun ScrollableDashboardContent(
    score: Int,
    isVpnActive: Boolean,
    isMonitorActive: Boolean,
    alertsFeed: List<com.example.data.AccessLog>,
    warningAlpha: Float,
    onNavigateToScanner: () -> Unit,
    onNavigateToAppLock: () -> Unit,
    onNavigateToVPN: () -> Unit,
    onNavigateToVault: () -> Unit,
    onNavigateToDarkWeb: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    viewModel: MainViewModel
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // 1. Scoring Meter Arc
        item {
            SecurityMeterCard(score = score)
        }

        // 2. Quick navigation scroll action chips
        item {
            QuickActionsRow(
                onNavigateToScanner = onNavigateToScanner,
                onNavigateToAppLock = onNavigateToAppLock,
                onNavigateToVPN = onNavigateToVPN,
                onNavigateToVault = onNavigateToVault,
                onNavigateToDarkWeb = onNavigateToDarkWeb,
                onNavigateToPermissions = onNavigateToPermissions
            )
        }

        // 3. Scam alert / Attention card (Conditional display based on score)
        if (score < 80) {
            item {
                ScamAlertCard(
                    warningAlpha = warningAlpha,
                    onStartScan = onNavigateToScanner
                )
            }
        }

        // 4. Live Sensor status cards
        item {
            LiveIndicatorsCard(
                isMonitorActive = isMonitorActive,
                isVpnActive = isVpnActive,
                onToggleMonitor = { viewModel.toggleProtectionMonitor() },
                onToggleVpn = { viewModel.toggleVpn() }
            )
        }

        // 5. Active Security Feed Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "سجل النشاط وتهديدات الأمان 🔴",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = "تحديث فوري",
                    color = CyanNeon,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal,
                    modifier = Modifier.clickable { viewModel.clearPhoneClipboard() } // Mock utility clear
                )
            }
        }

        // 6. Access Logs items chronologically
        items(alertsFeed.take(5)) { log ->
            FeedAlertItem(log = log)
        }
    }
}

@Composable
fun SecurityMeterCard(score: Int) {
    val scoreColor = when {
        score >= 90 -> GreenNeon
        score >= 75 -> CyanNeon
        else -> RedError
    }

    val stateText = when {
        score >= 90 -> "آمن للغاية"
        score >= 75 -> "حماية معتدلة"
        else -> "هاتفك معرض للتجسس!"
    }

    GlassCard(
        glowColor = scoreColor,
        glowRadius = 14.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "درجة أمان الهاتف",
                color = TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Glowing Arc visual meter
            Box(
                modifier = Modifier.size(170.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 14.dp.toPx()
                    val diameter = size.minDimension - strokeWidth
                    val size = Size(diameter, diameter)
                    val offset = Offset(strokeWidth / 2, strokeWidth / 2)

                    // Gray Track Arc
                    drawArc(
                        color = Color.DarkGray.copy(alpha = 0.5f),
                        startAngle = 135f,
                        sweepAngle = 270f,
                        useCenter = false,
                        style = Stroke(strokeWidth, cap = StrokeCap.Round),
                        size = size,
                        topLeft = offset
                    )

                    // Safe Progress Arc
                    drawArc(
                        color = scoreColor,
                        startAngle = 135f,
                        sweepAngle = (score / 100f) * 270f,
                        useCenter = false,
                        style = Stroke(strokeWidth, cap = StrokeCap.Round),
                        size = size,
                        topLeft = offset
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$score%",
                        color = Color.White,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.ExtraBold,
                        style = MaterialTheme.typography.displayLarge
                    )
                    Text(
                        text = stateText,
                        color = scoreColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "جدار الحماية والمسماس الذكي نشطون للكشف عن الجواسيس وسرقة البيانات.",
                color = TextSecondary,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
        }
    }
}

@Composable
fun QuickActionsRow(
    onNavigateToScanner: () -> Unit,
    onNavigateToAppLock: () -> Unit,
    onNavigateToVPN: () -> Unit,
    onNavigateToVault: () -> Unit,
    onNavigateToDarkWeb: () -> Unit,
    onNavigateToPermissions: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ActionChipItem(text = "فحص العميات", icon = Icons.Default.QrCodeScanner, color = CyanNeon, onClick = onNavigateToScanner)
        ActionChipItem(text = "قفل التطبيقات", icon = Icons.Default.Lock, color = PurpleNeon, onClick = onNavigateToAppLock)
        ActionChipItem(text = "جدار الحماية", icon = Icons.Default.Shield, color = CyanNeon, onClick = onNavigateToVPN)
        ActionChipItem(text = "الخزنة السرية", icon = Icons.Default.PhotoLibrary, color = GreenNeon, onClick = onNavigateToVault)
        ActionChipItem(text = "تسريبات الويب", icon = Icons.Default.Search, color = RedError, onClick = onNavigateToDarkWeb)
        ActionChipItem(text = "الأذونات", icon = Icons.Default.Apps, color = Color.Yellow, onClick = onNavigateToPermissions)
    }
}

@Composable
fun ActionChipItem(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = DarkSurface,
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.height(48.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            Icon(imageVector = icon, contentDescription = text, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun ScamAlertCard(
    warningAlpha: Float,
    onStartScan: () -> Unit
) {
    GlassCard(
        glowColor = RedError,
        glowRadius = 16.dp,
        modifier = Modifier.fillMaxWidth(),
        borderStroke = BorderStroke(1.dp, RedError.copy(alpha = warningAlpha))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(RedError.copy(alpha = 0.15f), CircleShape)
                    .border(1.dp, RedError, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Warning, contentDescription = "Security Breach warning", tint = RedError, modifier = Modifier.size(28.dp))
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "جهازك مهدد بالاختراق!",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = "الدرجة الأمنية منخفضة. هاتف غير محمي من هجمات التجسس وسحب الحافظة وسرقة الرموز.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Button(
                    onClick = onStartScan,
                    colors = ButtonDefaults.buttonColors(containerColor = RedError),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text(text = "إصلاح المشكلة فوراً ⚡", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun LiveIndicatorsCard(
    isMonitorActive: Boolean,
    isVpnActive: Boolean,
    onToggleMonitor: () -> Unit,
    onToggleVpn: () -> Unit
) {
    GlassCard(
        glowColor = CyanNeon,
        glowRadius = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text("حالة حماية حمو النشطة 🤖", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(14.dp))

        // Monitor item 1
        IndicatorRow(
            title = "مراقب المايك والكاميرا الفوري",
            checked = isMonitorActive,
            onCheckedChange = { onToggleMonitor() }
        )

        Divider(color = DarkBorder, modifier = Modifier.padding(vertical = 12.dp))

        // Monitor item 2
        IndicatorRow(
            title = "جدار الحماية المشفر والحجب الآمن",
            checked = isVpnActive,
            onCheckedChange = { onToggleVpn() }
        )
    }
}

@Composable
fun IndicatorRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(if (checked) GreenNeon else Color.Gray, CircleShape)
                    .shadow(if (checked) 8.dp else 0.dp, CircleShape, spotColor = GreenNeon, ambientColor = GreenNeon)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = CyanNeon,
                uncheckedThumbColor = Color.Gray,
                uncheckedTrackColor = Color.DarkGray
            )
        )
    }
}

@Composable
fun FeedAlertItem(log: com.example.data.AccessLog) {
    val levelColor = when (log.riskDegree) {
        "HIGH" -> RedError
        "MEDIUM" -> PurpleNeon
        else -> GreenNeon
    }

    val icon = when (log.sensorType) {
        "CAMERA" -> Icons.Default.CameraAlt
        "MICROPHONE" -> Icons.Default.Mic
        "CLIPBOARD" -> Icons.Default.ContentCopy
        "DARK_WEB" -> Icons.Default.RemoveRedEye
        "VAULT_ENCRYPT" -> Icons.Default.NoEncryption
        "CLEAN" -> Icons.Default.CheckCircle
        else -> Icons.Default.Security
    }

    Surface(
        color = DarkSurface,
        border = BorderStroke(0.5.dp, DarkBorder),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(levelColor.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = "alert", tint = levelColor, modifier = Modifier.size(18.dp))
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = log.appName,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = when (log.sensorType) {
                            "CAMERA" -> "حاول الوصول إلى كاميرا الهاتف بالخلفية."
                            "MICROPHONE" -> "استماع غير موثق إلى الميكروفون."
                            "CLIPBOARD" -> "مسح الحافظة لقراءة كلمات المرور المنسوخة."
                            "DARK_WEB" -> "تحذير: تم الكشف عن تسريب بريدي جديد."
                            "VAULT_ENCRYPT" -> "تم تشفير ملف بنجاح وإيداعه الخزنة."
                            "CLEAN" -> "تم إنهاء فحص النظام بنجاح - لا تهديدات."
                            else -> "تعديل في مستويات تصفية الحماية."
                        },
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
            }

            Text(
                text = "منذ قليل",
                color = Color.DarkGray,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

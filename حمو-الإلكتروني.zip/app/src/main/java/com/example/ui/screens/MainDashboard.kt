package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MainViewModel
import com.example.ui.components.GlassCard
import com.example.ui.theme.*

import androidx.compose.material.icons.filled.Menu
import kotlinx.coroutines.launch
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import android.util.Log

@Composable
fun MainDashboard(
    viewModel: MainViewModel,
    onNavigateToScanner: () -> Unit,
    onNavigateToAppLock: () -> Unit,
    onNavigateToVPN: () -> Unit,
    onNavigateToVault: () -> Unit,
    onNavigateToDarkWeb: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToDevProfile: () -> Unit,
    onNavigateToUssdCodes: () -> Unit
) {
    val score by viewModel.securityScore.collectAsState()
    val isVpnActive by viewModel.isVpnActive.collectAsState()
    val isMonitorActive by viewModel.isMonitorActive.collectAsState()
    val alertsFeed by viewModel.accessLogs.collectAsState()
    val scanRecordList by viewModel.scanRecords.collectAsState()

    // Real Hardware status radars
    val isCameraActive by viewModel.isCameraActive.collectAsState()
    val isAudioRecordingActive by viewModel.isAudioRecordingActive.collectAsState()

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    // Breathing pulse for warning alerts
    val infiniteTransition = rememberInfiniteTransition(label = "WarningFlash")
    val warningAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutQuad),
            repeatMode = RepeatMode.Reverse
        ),
        label = "AlphaFlash"
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = DeepDarkBg,
                drawerContentColor = Color.White,
                modifier = Modifier
                    .width(300.dp)
                    .fillMaxHeight(),
                windowInsets = WindowInsets.statusBars
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(DeepDarkBg)
                        .padding(24.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        // Header info
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(bottom = 24.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(GreenNeon.copy(alpha = 0.12f), CircleShape)
                                    .border(1.5.dp, GreenNeon, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = GreenNeon,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = "بوابة الحماية والمراقبة",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "تأمين وحماية النواة 2030",
                                    color = TextSecondary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Divider(color = DarkBorder, thickness = 1.dp, modifier = Modifier.padding(bottom = 16.dp))

                        Text(
                            text = "منظومات الحماية النشطة",
                            color = Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        // Drawer Navigation links
                        DrawerLinkItem(
                            title = "لوحة التحكم السيبرانية",
                            icon = Icons.Default.Home,
                            accentColor = GreenNeon,
                            onClick = {
                                scope.launch { drawerState.close() }
                            }
                        )

                        DrawerLinkItem(
                            title = "فحص البرمجيات الخبيثة والمخفية",
                            icon = Icons.Default.QrCodeScanner,
                            accentColor = CyanNeon,
                            onClick = {
                                scope.launch { drawerState.close() }
                                onNavigateToScanner()
                            }
                        )

                        DrawerLinkItem(
                            title = "جدار حماية تدفق البيانات",
                            icon = Icons.Default.Security,
                            accentColor = CyanNeon,
                            onClick = {
                                scope.launch { drawerState.close() }
                                onNavigateToVPN()
                            }
                        )

                        DrawerLinkItem(
                            title = "مستكشف ثغرات النظام العميقة",
                            icon = Icons.Default.CameraAlt,
                            accentColor = RedError,
                            onClick = {
                                scope.launch { drawerState.close() }
                                onNavigateToPermissions()
                            }
                        )

                        DrawerLinkItem(
                            title = "موسوعة الشفرات السيبرانية العربية",
                            icon = Icons.Default.Phone,
                            accentColor = PurpleNeon,
                            onClick = {
                                scope.launch { drawerState.close() }
                                onNavigateToUssdCodes()
                            }
                        )

                        DrawerLinkItem(
                            title = "مطور المنظومة الأمنية",
                            icon = Icons.Default.AccountBox,
                            accentColor = PurpleNeon,
                            onClick = {
                                scope.launch { drawerState.close() }
                                onNavigateToDevProfile()
                            }
                        )
                    }

                    // Strict developer security engineer signature at the bottom
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Divider(color = DarkBorder, thickness = 1.dp, modifier = Modifier.padding(bottom = 12.dp))
                        Text(
                            text = "إشراف هندسي: محمد حسام (حمو الإلكتروني) - خبير الأنظمة الدفاعية والأمن السيبراني © 2026",
                            color = Color.Gray,
                            fontSize = 9.sp,
                            lineHeight = 13.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DeepDarkBg)
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(top = 16.dp, start = 16.dp, end = 16.dp)
        ) {
            // --- Custom Top App Bar with hamburger menu ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { scope.launch { drawerState.open() } },
                        modifier = Modifier
                            .size(44.dp)
                            .border(1.dp, DarkBorder, CircleShape)
                            .background(DarkSurface, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "قائمة الخيارات",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("لوحة التحكم الدفاعية", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("حارس الأنظمة والأجهزة 🛰️", color = GreenNeon, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                // Crown Premium upgrade trigger pointing to dev profile
                IconButton(
                    onClick = { onNavigateToDevProfile() },
                    modifier = Modifier
                        .border(BorderStroke(1.dp, Brush.radialGradient(listOf(PurpleNeon, Color.Transparent))), CircleShape)
                        .background(PurpleNeon.copy(alpha = 0.15f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "الترقية للنسخة الذهبية",
                        tint = PurpleNeon
                    )
                }
            }

            // Real Hardware intruder warning status card
            if (isCameraActive || isAudioRecordingActive) {
                GlassCard(
                    glowColor = RedError,
                    glowRadius = 16.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    borderStroke = BorderStroke(1.dp, RedError.copy(alpha = warningAlpha))
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = RedError,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "رصد خرق أو نشاط نشط بالخلفية 🚨",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        if (isCameraActive) {
                            Text(
                                text = "• عدسة الكاميرا قيد الاستخدام والمراقبة بالخلفية حالياً!",
                                color = RedError,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (isAudioRecordingActive) {
                            Text(
                                text = "• ميكروفون الهاتف يسجل ويستمع للبيانات بالخلفية حالياً!",
                                color = RedError,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "يرجى غلق كل التطبيقات المشبوهة لتفادي التجسس وسحب الحافظة.",
                            color = Color.Gray,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }
                }
            }

            // --- Live Alerts Feed list and controls ---
            ScrollableDashboardContent(
                score = score,
                isVpnActive = isVpnActive,
                isMonitorActive = isMonitorActive,
                alertsFeed = alertsFeed,
                warningAlpha = warningAlpha,
                onNavigateToScanner = onNavigateToScanner,
                onNavigateToAppLock = onNavigateToAppLock,
                onNavigateToVPN = onNavigateToVPN,
                onNavigateToVault = onNavigateToVault,
                onNavigateToDarkWeb = onNavigateToDarkWeb,
                onNavigateToPermissions = onNavigateToPermissions,
                onNavigateToDevProfile = onNavigateToDevProfile,
                onNavigateToUssdCodes = onNavigateToUssdCodes,
                viewModel = viewModel
            )
        }
    }
}

@Composable
fun DrawerLinkItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = Color.Transparent,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun ScrollableDashboardContent(
    score: Int,
    isVpnActive: Boolean,
    isMonitorActive: Boolean,
    alertsFeed: List<com.example.data.AccessLog>,
    warningAlpha: Float,
    onNavigateToScanner: () -> Unit,
    onNavigateToAppLock: () -> Unit,
    onNavigateToVPN: () -> Unit,
    onNavigateToVault: () -> Unit,
    onNavigateToDarkWeb: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToDevProfile: () -> Unit,
    onNavigateToUssdCodes: () -> Unit,
    viewModel: MainViewModel
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // 1. Scoring Meter Arc
        item {
            SecurityMeterCard(score = score)
        }

        // 2. Quick navigation scroll action chips
        item {
            QuickActionsRow(
                onNavigateToScanner = onNavigateToScanner,
                onNavigateToAppLock = onNavigateToAppLock,
                onNavigateToVPN = onNavigateToVPN,
                onNavigateToVault = onNavigateToVault,
                onNavigateToDarkWeb = onNavigateToDarkWeb,
                onNavigateToPermissions = onNavigateToPermissions,
                onNavigateToUssdCodes = onNavigateToUssdCodes,
                onNavigateToDevProfile = onNavigateToDevProfile
            )
        }

        // 3. Scam alert / Attention card (Conditional display based on score)
        if (score < 80) {
            item {
                ScamAlertCard(
                    warningAlpha = warningAlpha,
                    onStartScan = onNavigateToScanner
                )
            }
        }

        // 4. Advanced USSD Communication Shield banner card
        item {
            GlassCard(
                glowColor = CyanNeon,
                glowRadius = 10.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToUssdCodes() }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(CyanNeon.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, CyanNeon, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "USSD codes section",
                            tint = CyanNeon,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "أكواد حماية الخط السريعة 📡",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "الكشف عن تجسس المكالمات وتحويل الشفرات الفوري وتصفير الاتصالات لمصر والدول العربية.",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Explore",
                        tint = Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // 4b. Interactive Wi-Fi Inspector core security tool
        item {
            var showWifiDialog by remember { mutableStateOf(false) }
            val wifiState by viewModel.wifiScanState.collectAsState()
            val wifiProgress by viewModel.wifiProgress.collectAsState()
            val wifiLogs by viewModel.wifiDetails.collectAsState()

            GlassCard(
                glowColor = GreenNeon,
                glowRadius = 10.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { 
                        showWifiDialog = true 
                        viewModel.resetWifiInspector() 
                    }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(GreenNeon.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, GreenNeon, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Wifi,
                            contentDescription = "Wi-Fi Inspector Security",
                            tint = GreenNeon,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "مفتش ومفجر ثغرات الواي فاي 📶",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "فحص استباقي لكشف هجمات حجب الإنترنت وحقن عناوين DNS ورصد التجسس على الحسابات البنكية.",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Open",
                        tint = Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            if (showWifiDialog) {
                AlertDialog(
                    onDismissRequest = { showWifiDialog = false },
                    containerColor = DarkSurface,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Wifi, contentDescription = null, tint = GreenNeon)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("مفتش الفحص اللاسلكي 🛰️", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                            Text(
                                text = "تحليل حزم البث والروتر ومنافذ الشبكة المتصل بها حالياً لمنع التجسس وقطع النت واصطياد الهجمات ARP.",
                                color = Color.Gray,
                                fontSize = 11.sp,
                                lineHeight = 15.sp,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )

                            if (wifiState == "IDLE") {
                                Button(
                                    onClick = { viewModel.startWifiInspectorScan() },
                                    colors = ButtonDefaults.buttonColors(containerColor = GreenNeon),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("ابدأ فحص الشبكة الوقائي ⚡", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            } else {
                                LinearProgressIndicator(
                                    progress = { wifiProgress },
                                    color = GreenNeon,
                                    trackColor = Color.DarkGray,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(130.dp)
                                        .background(Color.Black, RoundedCornerShape(10.dp))
                                        .border(0.5.dp, Color.DarkGray, RoundedCornerShape(10.dp))
                                        .padding(10.dp)
                                ) {
                                    LazyColumn(
                                        modifier = Modifier.fillMaxSize(),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        items(wifiLogs) { log ->
                                            Text(
                                                text = "🟢 $log",
                                                color = GreenNeon,
                                                fontSize = 11.sp,
                                                lineHeight = 15.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }
                                }

                                if (wifiState == "SECURE") {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "🛡️ تم فك التشفير: شبكتك آمنة ومطابقة بنسبة ١٠٠% لشروط حمو السيبرانية حيال التسريب!",
                                        color = GreenNeon,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(
                            onClick = { showWifiDialog = false },
                            colors = ButtonDefaults.textButtonColors(contentColor = GreenNeon)
                        ) {
                            Text("إغلاق", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }
        }

        // 5. Live Sensor status cards
        item {
            LiveIndicatorsCard(
                isMonitorActive = isMonitorActive,
                isVpnActive = isVpnActive,
                onToggleMonitor = { viewModel.toggleProtectionMonitor() },
                onToggleVpn = { viewModel.toggleVpn() }
            )
        }

        // 6. Active Security Feed Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "سجل النشاط وتهديدات الأمان 🔴",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = "تصفير الحافظة",
                    color = CyanNeon,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Normal,
                    modifier = Modifier.clickable { viewModel.clearPhoneClipboard() } // Mock utility clear
                )
            }
        }

        // 7. Access Logs items chronologically
        items(alertsFeed.take(5)) { log ->
            FeedAlertItem(log = log)
        }

        // 8. Creative Developer manifesto promotion card
        item {
            GlassCard(
                glowColor = PurpleNeon,
                glowRadius = 12.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToDevProfile() }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(PurpleNeon.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, PurpleNeon, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Hamo Elketeroni info",
                            tint = PurpleNeon,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "منظومات المهندس حمو الإلكتروني 💻",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "عرض ملف المبتكر، قنوات الشروحات التعليمية وقلاع بناء البرمجيات الوقائية الحقيقية.",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Explore",
                        tint = Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // 10. Clipboard Guardian Panel (رادار الحافة)
        item {
            val isClipboardActive by viewModel.isClipboardGuardianActive.collectAsState()
            GlassCard(
                glowColor = if (isClipboardActive) PurpleNeon else Color.Gray,
                glowRadius = 10.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(if (isClipboardActive) PurpleNeon.copy(alpha = 0.12f) else Color.DarkGray.copy(alpha = 0.12f), CircleShape)
                                .border(1.dp, if (isClipboardActive) PurpleNeon else Color.Gray, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Assignment,
                                contentDescription = "Clipboard Radar",
                                tint = if (isClipboardActive) PurpleNeon else Color.Gray,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "رادار حظر التجسس على الحافظة 📋",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "مراقب قراءة الحافظة النشط - تم إحباط محاولة سحب النصوص المشفرة وحماية محافظ الكريبتو الحيوية.",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(14.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isClipboardActive) "مراقب الحافظة: نشط وآمن 🔒" else "مراقب الحافظة: خامل وغير مفعّل",
                            color = if (isClipboardActive) PurpleNeon else Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Button(
                            onClick = { viewModel.toggleClipboardGuardian() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isClipboardActive) PurpleNeon else DarkSurface
                            ),
                            border = BorderStroke(1.dp, if (isClipboardActive) PurpleNeon else Color.Gray),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Text(
                                text = if (isClipboardActive) "تعطيل الرادار" else "تفعيل رادار الحماية",
                                color = if (isClipboardActive) Color.White else Color.Gray,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 11. CA Certificate & Proxy Hijack Scanner
        item {
            var showCertDialog by remember { mutableStateOf(false) }
            var reportState by remember { mutableStateOf<com.example.data.CertProxyReport?>(null) }
            val context = LocalContext.current

            GlassCard(
                glowColor = CyanNeon,
                glowRadius = 10.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        reportState = viewModel.checkUserCertificatesAndProxy()
                        showCertDialog = true
                    }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(CyanNeon.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, CyanNeon, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "MITM Shield",
                            tint = CyanNeon,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "مستكشف شهادات التجسس والوكيل 🕵️‍♂️",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "كاشف هجمات رجل المنتصف وتعديل الشهادات الجذرية للنواة والبروكسي الخارجي للحزمة.",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Scan CA",
                        tint = Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            if (showCertDialog && reportState != null) {
                val report = reportState!!
                AlertDialog(
                    onDismissRequest = { showCertDialog = false },
                    containerColor = DarkSurface,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = if (report.isThreat) RedError else GreenNeon)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("درع كشف الشهادات والوكلاء 🔐", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                text = report.cyberText,
                                color = if (report.isThreat) RedError else GreenNeon,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = report.details,
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                            if (report.isThreat) {
                                Text(
                                    text = "تنبيه: حركة مرور البيانات تحت المراقبة وفك التشفير برأس مال خارجي!",
                                    color = RedError,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    },
                    confirmButton = {
                        if (report.isThreat) {
                            Button(
                                onClick = {
                                    try {
                                        context.startActivity(Intent("android.settings.SECURITY_SETTINGS"))
                                    } catch (e: Exception) {
                                        try {
                                            context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                                        } catch (ignored: Exception) {}
                                    }
                                    showCertDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = RedError)
                            ) {
                                Text("إزالة الشهادات فوراً ⚙️", color = Color.White)
                            }
                        } else {
                            Button(
                                onClick = { showCertDialog = false },
                                colors = ButtonDefaults.buttonColors(containerColor = GreenNeon)
                            ) {
                                Text("حسنًا 👍", color = Color.Black)
                            }
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showCertDialog = false }) {
                            Text("إغلاق", color = Color.Gray)
                        }
                    }
                )
            }
        }

        // 12. Overlay Attack & Screen Injection Detector
        item {
            var showOverlayDialog by remember { mutableStateOf(false) }
            var overlayReportList by remember { mutableStateOf<List<com.example.data.OverlayAppReport>>(emptyList()) }
            val context = LocalContext.current

            GlassCard(
                glowColor = RedError,
                glowRadius = 10.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        overlayReportList = viewModel.scanOverlayThreats()
                        showOverlayDialog = true
                    }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(RedError.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, RedError, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Overlay Hijack Shield",
                            tint = RedError,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "مستكشف الهجمات التراكبية وحقن الشاشات 🎭",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "نظام اصطياد برمجيات التراكب الخبيثة وحقن الواجهات والظهور فوق التطبيقات لتسجيل ضغطات المفاتيح.",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Scan Overlay",
                        tint = Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            if (showOverlayDialog) {
                AlertDialog(
                    onDismissRequest = { showOverlayDialog = false },
                    containerColor = DarkSurface,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = RedError)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("رادار رصد النوافذ والتراكبات 🚨", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "نظام اصطياد برمجيات التراكب الخبيثة وحقن الواجهات",
                                color = RedError,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            
                            if (overlayReportList.isEmpty()) {
                                Text(
                                    text = "لم يتم الكشف عن تطبيقات مشبوهة بمستويات تراكب نشطة فوق الشاشة الرئيسية. وظائف الهاتف مؤمنة بكفاءة حمو.",
                                    color = Color.LightGray,
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )
                            } else {
                                Box(modifier = Modifier.fillMaxWidth().height(200.dp)) {
                                    LazyColumn(
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        items(overlayReportList) { app ->
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .background(RedError.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                                    .border(1.dp, RedError.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                                    .padding(8.dp)
                                            ) {
                                                Text(app.appLabel, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                                Text(app.packageName, color = Color.Gray, fontSize = 9.sp)
                                                Text(app.explanation, color = Color.LightGray, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
                                                
                                                Spacer(modifier = Modifier.height(8.dp))
                                                
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    // Purge app background
                                                    Button(
                                                        onClick = {
                                                            viewModel.militaryForceStopApp(app.packageName)
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = RedError),
                                                        shape = RoundedCornerShape(8.dp),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .height(28.dp)
                                                    ) {
                                                        Text("تطهير عسكري 💥", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                    
                                                    // Open system app details
                                                    Button(
                                                        onClick = {
                                                            try {
                                                                val intent = Intent(
                                                                    android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                                                    android.net.Uri.parse("package:${app.packageName}")
                                                                )
                                                                context.startActivity(intent)
                                                            } catch (e: Exception) {
                                                                Log.e("MainDashboard", "Failed opening details settings", e)
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurface),
                                                        border = BorderStroke(1.dp, Color.Gray),
                                                        shape = RoundedCornerShape(8.dp),
                                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .height(28.dp)
                                                    ) {
                                                        Text("توجيه للحذف ⚙️", color = Color.LightGray, fontSize = 9.sp)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = { showOverlayDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = if (overlayReportList.isEmpty()) GreenNeon else RedError)
                        ) {
                            Text("إغلاق", color = if (overlayReportList.isEmpty()) Color.Black else Color.White)
                        }
                    }
                )
            }
        }

        // 9. Banner Ad located elegantly at the bottom
        item {
            com.example.ui.components.BannerAdView(modifier = Modifier.padding(vertical = 8.dp))
        }
    }
}

@Composable
fun SecurityMeterCard(score: Int) {
    val scoreColor = when {
        score >= 90 -> GreenNeon
        score >= 75 -> CyanNeon
        else -> RedError
    }

    val stateText = when {
        score >= 90 -> "آمن للغاية"
        score >= 75 -> "حماية معتدلة"
        else -> "هاتفك معرض للتجسس!"
    }

    GlassCard(
        glowColor = scoreColor,
        glowRadius = 14.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "درجة أمان الهاتف",
                color = TextSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Glowing Arc visual meter
            Box(
                modifier = Modifier.size(170.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 14.dp.toPx()
                    val diameter = size.minDimension - strokeWidth
                    val size = Size(diameter, diameter)
                    val offset = Offset(strokeWidth / 2, strokeWidth / 2)

                    // Gray Track Arc
                    drawArc(
                        color = Color.DarkGray.copy(alpha = 0.5f),
                        startAngle = 135f,
                        sweepAngle = 270f,
                        useCenter = false,
                        style = Stroke(strokeWidth, cap = StrokeCap.Round),
                        size = size,
                        topLeft = offset
                    )

                    // Safe Progress Arc
                    drawArc(
                        color = scoreColor,
                        startAngle = 135f,
                        sweepAngle = (score / 100f) * 270f,
                        useCenter = false,
                        style = Stroke(strokeWidth, cap = StrokeCap.Round),
                        size = size,
                        topLeft = offset
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$score%",
                        color = Color.White,
                        fontSize = 44.sp,
                        fontWeight = FontWeight.ExtraBold,
                        style = MaterialTheme.typography.displayLarge
                    )
                    Text(
                        text = stateText,
                        color = scoreColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "جدار الحماية والمسماس الذكي نشطون للكشف عن الجواسيس وسرقة البيانات.",
                color = TextSecondary,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            )
        }
    }
}

@Composable
fun QuickActionsRow(
    onNavigateToScanner: () -> Unit,
    onNavigateToAppLock: () -> Unit,
    onNavigateToVPN: () -> Unit,
    onNavigateToVault: () -> Unit,
    onNavigateToDarkWeb: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToUssdCodes: () -> Unit,
    onNavigateToDevProfile: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ActionChipItem(text = "فحص العمليات", icon = Icons.Default.QrCodeScanner, color = CyanNeon, onClick = onNavigateToScanner)
        ActionChipItem(text = "أكواد الشبكة 📡", icon = Icons.Default.Phone, color = CyanNeon, onClick = onNavigateToUssdCodes)
        ActionChipItem(text = "المبتكر حمو", icon = Icons.Default.Star, color = PurpleNeon, onClick = onNavigateToDevProfile)
        ActionChipItem(text = "قفل التطبيقات", icon = Icons.Default.Lock, color = PurpleNeon, onClick = onNavigateToAppLock)
        ActionChipItem(text = "جدار الحماية", icon = Icons.Default.Shield, color = CyanNeon, onClick = onNavigateToVPN)
        ActionChipItem(text = "الخزنة السرية", icon = Icons.Default.PhotoLibrary, color = GreenNeon, onClick = onNavigateToVault)
        ActionChipItem(text = "تسريبات الويب", icon = Icons.Default.Search, color = RedError, onClick = onNavigateToDarkWeb)
        ActionChipItem(text = "الأذونات", icon = Icons.Default.Apps, color = Color.Yellow, onClick = onNavigateToPermissions)
    }
}

@Composable
fun ActionChipItem(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = DarkSurface,
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.height(48.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            Icon(imageVector = icon, contentDescription = text, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun ScamAlertCard(
    warningAlpha: Float,
    onStartScan: () -> Unit
) {
    GlassCard(
        glowColor = RedError,
        glowRadius = 16.dp,
        modifier = Modifier.fillMaxWidth(),
        borderStroke = BorderStroke(1.dp, RedError.copy(alpha = warningAlpha))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(RedError.copy(alpha = 0.15f), CircleShape)
                    .border(1.dp, RedError, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Warning, contentDescription = "Security Breach warning", tint = RedError, modifier = Modifier.size(28.dp))
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "جهازك مهدد بالاختراق!",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Text(
                    text = "الدرجة الأمنية منخفضة. هاتف غير محمي من هجمات التجسس وسحب الحافظة وسرقة الرموز.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Button(
                    onClick = onStartScan,
                    colors = ButtonDefaults.buttonColors(containerColor = RedError),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text(text = "إصلاح المشكلة فوراً ⚡", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun LiveIndicatorsCard(
    isMonitorActive: Boolean,
    isVpnActive: Boolean,
    onToggleMonitor: () -> Unit,
    onToggleVpn: () -> Unit
) {
    GlassCard(
        glowColor = CyanNeon,
        glowRadius = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text("حالة حماية حمو النشطة 🤖", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(14.dp))

        // Monitor item 1
        IndicatorRow(
            title = "مراقب المايك والكاميرا الفوري",
            checked = isMonitorActive,
            onCheckedChange = { onToggleMonitor() }
        )

        Divider(color = DarkBorder, modifier = Modifier.padding(vertical = 12.dp))

        // Monitor item 2
        IndicatorRow(
            title = "جدار الحماية المشفر والحجب الآمن",
            checked = isVpnActive,
            onCheckedChange = { onToggleVpn() }
        )
    }
}

@Composable
fun IndicatorRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(if (checked) GreenNeon else Color.Gray, CircleShape)
                    .shadow(if (checked) 8.dp else 0.dp, CircleShape, spotColor = GreenNeon, ambientColor = GreenNeon)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = CyanNeon,
                uncheckedThumbColor = Color.Gray,
                uncheckedTrackColor = Color.DarkGray
            )
        )
    }
}

@Composable
fun FeedAlertItem(log: com.example.data.AccessLog) {
    val levelColor = when (log.riskDegree) {
        "HIGH" -> RedError
        "MEDIUM" -> PurpleNeon
        else -> GreenNeon
    }

    val icon = when (log.sensorType) {
        "CAMERA" -> Icons.Default.CameraAlt
        "MICROPHONE" -> Icons.Default.Mic
        "CLIPBOARD" -> Icons.Default.ContentCopy
        "DARK_WEB" -> Icons.Default.RemoveRedEye
        "VAULT_ENCRYPT" -> Icons.Default.NoEncryption
        "CLEAN" -> Icons.Default.CheckCircle
        else -> Icons.Default.Security
    }

    Surface(
        color = DarkSurface,
        border = BorderStroke(0.5.dp, DarkBorder),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(levelColor.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = "alert", tint = levelColor, modifier = Modifier.size(18.dp))
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = log.appName,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = when (log.sensorType) {
                            "CAMERA" -> "حاول الوصول إلى كاميرا الهاتف بالخلفية."
                            "MICROPHONE" -> "استماع غير موثق إلى الميكروفون."
                            "CLIPBOARD" -> "مسح الحافظة لقراءة كلمات المرور المنسوخة."
                            "DARK_WEB" -> "تحذير: تم الكشف عن تسريب بريدي جديد."
                            "VAULT_ENCRYPT" -> "تم تشفير ملف بنجاح وإيداعه الخزنة."
                            "CLEAN" -> "تم إنهاء فحص النظام بنجاح - لا تهديدات."
                            else -> "تعديل في مستويات تصفية الحماية."
                        },
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
            }

            Text(
                text = "منذ قليل",
                color = Color.DarkGray,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

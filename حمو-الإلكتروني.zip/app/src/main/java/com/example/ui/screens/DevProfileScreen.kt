package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlassCard
import com.example.ui.components.BannerAdView
import com.example.ui.theme.*

@Composable
fun DevProfileScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val telegramUrl = "https://t.me/hamoelctronic2007"
    val whatsappUrl = "https://wa.me/201012345678" // Professional WhatsApp contact fallback or community
    val youtubeUrl = "https://youtube.com/@HamoElketeroni"
    val websiteUrl = "https://hamo-cyber-shield.github.io"

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepDarkBg)
            .statusBarsPadding()
            .navigationBarsPadding(),
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .border(1.dp, Color.DarkGray, CircleShape)
                        .background(DarkSurface, CircleShape)
                ) {
                    Icon(Icons.Default.ChevronRight, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = "مهندس المشروع والمبتكر 💻",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        bottomBar = {
            BannerAdView(modifier = Modifier.padding(12.dp))
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            
            // Neon Avatar Holder Group
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(CyanNeon.copy(alpha = 0.2f), Color.Transparent)
                        ),
                        shape = CircleShape
                    )
                    .border(2.dp, CyanNeon, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                // Futuristic Glowing Cyber Symbol Icon
                Text(
                    text = "🤖",
                    fontSize = 48.sp,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Developer Name with Cyber Highlight
            Text(
                text = "مُحمَّد حُسام",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )
            
            Text(
                text = "( حَمـو الإلكترونـي )",
                color = CyanNeon,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 2.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "مستشار أمن المعلومات والبرمجيات الوقائية المتقدمة",
                color = Color.Gray,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // The Core Bio Manifesto glassmorphism card
            GlassCard(
                glowColor = PurpleNeon,
                glowRadius = 16.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "بيان القيادة السيبرانية 🛡️",
                    color = PurpleNeon,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                Text(
                    text = "محمد حسام (حمو الإلكتروني) - مهندس أمن سيبراني هجومي ومطور برمجيات شامل ومؤسس قلاع حمو الإلكتروني التعليمية. نحن لا نصنع مستخدمين للأدوات بل مبتكرين قادرين على التفكيك والتحليل والبناء.\n\nأخصائي اختبار اختراق، خبير في الهندسة العكسية، محلل برمجيات خبيثة، مفكك أكواد ملغمة، وصائد ثغرات. ندمج حلول التحليل المتقدمة وهندسة النواة لبناء أنظمة دفاعية استباقية بالهجمات.\n\nالمحترفون يبنون أدواتهم، والهواة يستخدمون أدوات الآخرين.",
                    color = Color.White,
                    fontSize = 13.sp,
                    lineHeight = 22.sp,
                    textAlign = TextAlign.Justify
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "قنوات الاتصال والبناء 📡",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp, end = 4.dp),
                textAlign = TextAlign.Start
            )

            // Neon contact link actions
            SocialCardLink(
                title = "قناة التيليجرام التعليمية 📢",
                subtitle = "تابع شروحات الهندسة العكسية وفك الأكواد مباشرة",
                color = CyanNeon,
                iconUnit = Icons.Default.Send,
                onClick = { openLinkInBrowser(context, telegramUrl) }
            )

            Spacer(modifier = Modifier.height(10.dp))

            SocialCardLink(
                title = "مجتمع قلاع حمو السيبرانية (واتساب) 💬",
                subtitle = "تبادل المناقشات البرمجية والأمنية مع الزملاء",
                color = GreenNeon,
                iconUnit = Icons.Default.Share,
                onClick = { openLinkInBrowser(context, whatsappUrl) }
            )

            Spacer(modifier = Modifier.height(10.dp))

            SocialCardLink(
                title = "قناة اليوتيوب الرسمية 🎥",
                subtitle = "شاهد دروس تحليل البرمجيات الخبيثة وصيد الثغرات",
                color = RedError,
                iconUnit = Icons.Default.PlayArrow,
                onClick = { openLinkInBrowser(context, youtubeUrl) }
            )

            Spacer(modifier = Modifier.height(10.dp))

            SocialCardLink(
                title = "مستودع الأبحاث والموقع الرسمي 🌐",
                subtitle = "قم بتنزيل أدوات التحليل الدفاعي المصنعة يدوياً",
                color = Color.Yellow,
                iconUnit = Icons.Default.Language,
                onClick = { openLinkInBrowser(context, websiteUrl) }
            )

            Spacer(modifier = Modifier.height(30.dp))
            
            // Small educational motto slogan footer
            Text(
                text = "« حمو الإلكتروني - لجيل حقيقي يصنع أنظمته بنفسه »\n\nتطوير وإشراف هندسي: محمد حسام (حمو الإلكتروني) - خبير الأنظمة الدفاعية والأمن السيبراني © 2026",
                color = Color.Gray,
                fontSize = 11.sp,
                lineHeight = 16.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }
    }
}

@Composable
fun SocialCardLink(
    title: String,
    subtitle: String,
    color: Color,
    iconUnit: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = DarkSurface,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(color.copy(alpha = 0.1f), CircleShape)
                    .border(1.dp, color.copy(alpha = 0.4f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = iconUnit,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = subtitle,
                    color = Color.Gray,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Open",
                tint = Color.DarkGray,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

private fun openLinkInBrowser(context: Context, url: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "لم نتمكن من فتح المتصفح. الرابط: $url", Toast.LENGTH_SHORT).show()
    }
}

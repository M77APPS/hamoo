package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val CyberDarkColorScheme = darkColorScheme(
    primary = CyanNeon,
    primaryContainer = PrimaryContainer,
    onPrimary = OnPrimary,
    secondary = PurpleNeon,
    secondaryContainer = SecondaryContainer,
    tertiary = GreenNeon,
    background = DeepDarkBg,
    surface = DarkSurface,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = RedError,
    outline = DarkBorder
)

// We fallback to dark styling for cyberpunk feel, but can keep light scheme just in case.
private val CyberLightColorScheme = lightColorScheme(
    primary = CyanNeon,
    primaryContainer = PrimaryContainer,
    onPrimary = OnPrimary,
    secondary = PurpleNeon,
    secondaryContainer = SecondaryContainer,
    tertiary = GreenNeon,
    background = DeepDarkBg, // Keep deep dark backgrounds for consistency
    surface = DarkSurface,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = RedError,
    outline = DarkBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force Dark Cyberpunk elegance by default
    dynamicColor: Boolean = false, // Disable dynamic colors (monochrome/dynamic wallpapers clash with Cyberpunk Neon theme)
    content: @Composable () -> Unit
) {
    val colorScheme = CyberDarkColorScheme // Force stunning CyberDark!

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = DeepDarkBg.toArgb()
            window.navigationBarColor = DeepDarkBg.toArgb()
            
            val windowInsetsController = WindowCompat.getInsetsController(window, view)
            windowInsetsController.isAppearanceLightStatusBars = false
            windowInsetsController.isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

package com.example.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity

class ProtectionVpnService : VpnService(), Runnable {
    private var mThread: Thread? = null
    private var mInterface: ParcelFileDescriptor? = null
    private var isPlaying = false

    companion object {
        const val ACTION_START = "com.example.services.vpn.START"
        const val ACTION_STOP = "com.example.services.vpn.STOP"
        private const val NOTIFICATION_ID = 4529
        private const val CHANNEL_ID = "vpn_channel"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopVpn()
            return START_NOT_STICKY
        }
        
        startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        if (isPlaying) return
        isPlaying = true
        
        createNotificationChannel()
        val notification = createNotification()
        startForeground(NOTIFICATION_ID, notification)

        mThread = Thread(this, "ProtectionVpnThread").apply {
            start()
        }
        Log.i("ProtectionVpnService", "Hamo VPN Service Started.")
    }

    private fun stopVpn() {
        isPlaying = false
        mThread?.interrupt()
        mThread = null
        try {
            mInterface?.close()
        } catch (e: Exception) {
            Log.e("ProtectionVpnService", "Error closing VPN interface", e)
        }
        mInterface = null
        stopForeground(true)
        stopSelf()
        Log.i("ProtectionVpnService", "Hamo VPN Service Stopped.")
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    override fun run() {
        try {
            // Configure VPN interface
            val builder = Builder()
                .setSession("حمو الإلكتروني - Smart Shield")
                .addAddress("10.0.0.1", 24)
                .addDnsServer("1.1.1.1")
                .addDnsServer("8.8.8.8")
                .addRoute("0.0.0.0", 0)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                builder.setMetered(false)
            }

            mInterface = builder.establish()

            // Main VPN loop - read from interface and write (mocked blocking channel)
            while (isPlaying) {
                Thread.sleep(1000)
                if (Thread.currentThread().isInterrupted) break
            }
        } catch (e: Exception) {
            Log.e("ProtectionVpnService", "Exception in VPN tunnel", e)
        } finally {
            try {
                mInterface?.close()
            } catch (ignored: Exception) {}
            mInterface = null
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "جدار حماية حمو الإلكتروني",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "قناة إشعارات جدار الحماية والاتصال الآمن"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("جدار حمايه حمو نشط 🛡️")
            .setContentText("يتم حماية اتصالات الهاتف والروابط المشبوهة الآن.")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }
}

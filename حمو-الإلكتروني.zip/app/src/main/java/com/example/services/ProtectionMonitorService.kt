package com.example.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity

class ProtectionMonitorService : Service() {

    companion object {
        const val ACTION_START = "com.example.services.monitor.START"
        const val ACTION_STOP = "com.example.services.monitor.STOP"
        private const val NOTIFICATION_ID = 4530
        private const val CHANNEL_ID = "monitor_channel"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopMonitor()
            return START_NOT_STICKY
        }

        startMonitor()
        return START_STICKY
    }

    private fun startMonitor() {
        createNotificationChannel()
        val notification = createNotification()
        startForeground(NOTIFICATION_ID, notification)
        Log.i("ProtectionMonitor", "Security Monitor Service Started.")
    }

    private fun stopMonitor() {
        stopForeground(true)
        stopSelf()
        Log.i("ProtectionMonitor", "Security Monitor Service Stopped.")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "درع حمو الإلكتروني النشط",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "حماية فورية لمراقبة الكاميرا، الميكروفون، وسرقة البيانات"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("درع حمو نشط لحمايتك 🛡️")
            .setContentText("مراقبة مستمرة للكاميرا والمايكروفون وخطف الشاشة.")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
    }
}
